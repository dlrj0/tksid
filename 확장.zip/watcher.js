// watcher.js
// 이 스크립트는 열려 있는 "모든" 탭에 삽입되지만,
// 실제로는 MesoTimer 페이지(#timerDisplay 요소가 있는 페이지)에서만 동작합니다.

(function () {
  const isTimerPage = !!document.getElementById("timerDisplay");
  if (!isTimerPage) return; // 타이머 페이지가 아니면 아무 것도 하지 않음

  // [HOTKEY] 이 탭이 타이머 페이지라는 걸 background에 알린다. 전역 단축키가
  // 눌렸을 때 background가 모든 탭을 뒤지지 않고 바로 이 탭으로 메시지를
  // 보낼 수 있게 하기 위함(background.js의 timerTabIds 참고).
  chrome.runtime.sendMessage({ type: "MAPLE_TIMER_PAGE_READY" });

  // [HOTKEY] background(전역 단축키 리스너)와 페이지 스크립트(타이머.html)는
  // 서로 격리된 컨텍스트라 직접 함수를 호출할 수 없다. CustomEvent로 다리를
  // 놓고, 실제 동작(fastRestart/일시정지 토글/소리 피드백)은 페이지 쪽에서 구현한다.
  chrome.runtime.onMessage.addListener((message) => {
    switch (message?.type) {
      case "MAPLE_TIMER_HOTKEY_RESET":
        document.dispatchEvent(new CustomEvent("MAPLE_TIMER_HOTKEY_RESET"));
        break;
      case "MAPLE_TIMER_HOTKEY_TOGGLE_PAUSE":
        document.dispatchEvent(
          new CustomEvent("MAPLE_TIMER_HOTKEY_TOGGLE_PAUSE")
        );
        break;
      case "MAPLE_TIMER_HOTKEY_MASTER_TOGGLE":
        document.dispatchEvent(
          new CustomEvent("MAPLE_TIMER_HOTKEY_MASTER_TOGGLE", {
            detail: { enabled: !!message.enabled },
          })
        );
        break;
      case "MAPLE_TIMER_HOTKEY_SNOOZE_TOGGLE":
        document.dispatchEvent(
          new CustomEvent("MAPLE_TIMER_HOTKEY_SNOOZE_TOGGLE", {
            detail: { enabled: !!message.enabled },
          })
        );
        break;
      // [HOTKEY-EXPAND] 신규 3종(강제정지/강제재생/자동기능토글)도 동일한 브릿지
      // 패턴 재사용 — 이 탭이 실제로 미디어를 갖고 있는지와 무관하게, 타이머 탭에는
      // 늘 결과를 들을 수 있게(=화면을 안 보고 있어도 피크음으로 알 수 있게) 전달.
      case "MAPLE_TIMER_HOTKEY_FORCE_PAUSE":
        document.dispatchEvent(new CustomEvent("MAPLE_TIMER_HOTKEY_FORCE_PAUSE"));
        break;
      case "MAPLE_TIMER_HOTKEY_FORCE_RESUME":
        document.dispatchEvent(new CustomEvent("MAPLE_TIMER_HOTKEY_FORCE_RESUME"));
        break;
      case "MAPLE_TIMER_HOTKEY_AUTO_TOGGLE":
        document.dispatchEvent(
          new CustomEvent("MAPLE_TIMER_HOTKEY_AUTO_TOGGLE", {
            detail: { enabled: !!message.enabled },
          })
        );
        break;
    }
  });

  let wasAlarming = false;
  // [RESET-SIGNAL] index.html의 notifyReset()이 body에 찍는, 1씩 증가하는 카운터.
  // 값이 바뀔 때마다(리셋이 발생할 때마다) 재생 신호를 보냄.
  let lastResetSeq = document.body ? document.body.getAttribute("data-reset-seq") : null;

  function checkAlarmState() {
    const body = document.body;
    if (!body) return;
    const isAlarming = body.classList.contains("alarm-state");

    // 알람이 "꺼짐 -> 켜짐"으로 바뀌는 순간에만 신호를 보냄 (정지 신호)
    if (isAlarming && !wasAlarming) {
      chrome.runtime.sendMessage({ type: "MAPLE_TIMER_ALARM" });
    }
    wasAlarming = isAlarming;

    // [RESET-SIGNAL] 리셋 카운터가 바뀌면 재생 신호를 보냄
    const currentResetSeq = body.getAttribute("data-reset-seq");
    if (currentResetSeq !== null && currentResetSeq !== lastResetSeq) {
      lastResetSeq = currentResetSeq;
      chrome.runtime.sendMessage({ type: "MAPLE_TIMER_RESET" });
    }
  }

  const observer = new MutationObserver(checkAlarmState);
  observer.observe(document.body, {
    attributes: true,
    attributeFilter: ["class", "data-reset-seq"],
  });

  // 초기 상태 체크(새로고침 직후 이미 알람 상태일 수도 있으므로)
  checkAlarmState();
})();
