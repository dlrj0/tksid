const check = document.getElementById("enabledCheck");
const status = document.getElementById("status");
const selectedListEl = document.getElementById("selectedList");
const candidateListEl = document.getElementById("candidateList");
const activeTabRowEl = document.getElementById("activeTabRow");
const snoozeCheck = document.getElementById("snoozeCheck");
const pausedListEl = document.getElementById("pausedList");
const pausedCountEl = document.getElementById("pausedCount");

// ---- 켜짐/꺼짐 토글 (기존 기능) ----------------------------------------

chrome.storage.local.get(["enabled"], ({ enabled }) => {
  check.checked = enabled !== false; // 기본값 true
  renderStatus();
});

check.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: check.checked }, async () => {
    renderStatus();
    // [BADGE] 꺼지는 순간 배지를 바로 비우고, 켜지는 순간엔 이미 정지되어 있던
    // 탭 수를 즉시 반영한다(다음 알람/리셋을 기다릴 필요 없이 아이콘이 바로 맞아야 함).
    if (!check.checked) {
      chrome.action.setBadgeText({ text: "" });
    } else {
      // [HOTKEY] 단축키가 꺼져 있는 상태라면 그 "OFF" 배지를 되살려두고,
      // 켜져 있을 때만 기존처럼 정지된 탭 수 배지를 보여준다.
      const { hotkeysEnabled } = await chrome.storage.local.get([
        "hotkeysEnabled",
      ]);
      if (hotkeysEnabled === false) {
        chrome.action.setBadgeBackgroundColor({ color: "#71717a" });
        chrome.action.setBadgeText({ text: "OFF" });
        return;
      }
      chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
      const { pausedTabIds = [] } = await chrome.storage.session.get([
        "pausedTabIds",
      ]);
      chrome.action.setBadgeText({
        text: pausedTabIds.length > 0 ? String(pausedTabIds.length) : "",
      });
    }
  });
});

function renderStatus() {
  status.textContent = check.checked
    ? "켜짐: 알람이 울리면 선택한 탭(또는 전체 탭)의 영상이 자동으로 멈추고, 리셋되면 다시 재생됩니다."
    : "꺼짐: 자동 정지/재생 기능이 비활성화되었습니다.";
}

// ---- 스누즈(다음 알람 한 번 건너뛰기) -----------------------------------
// [SNOOZE] chrome.storage.session에 저장하는 1회성 플래그. background.js의
// handleAlarm()이 알람을 처리할 때 이 값을 확인해 true면 이번 알람만 건너뛰고
// 스스로 false로 되돌린다(소모성). 그래서 팝업을 다시 열 때마다 최신 상태를
// 다시 읽어와야 하며(이미 소모됐을 수 있으므로), renderAll()에서 매번 갱신한다.
if (snoozeCheck) {
  chrome.storage.session.get(["snoozeNextAlarm"], ({ snoozeNextAlarm }) => {
    snoozeCheck.checked = !!snoozeNextAlarm;
  });

  snoozeCheck.addEventListener("change", () => {
    chrome.storage.session.set({ snoozeNextAlarm: snoozeCheck.checked });
  });
}

// ---- 전역 단축키(핫키) ---------------------------------------------------

const hotkeysEnabledCheck = document.getElementById("hotkeysEnabledCheck");
const commandsListEl = document.getElementById("commandsList");
const btnOpenShortcuts = document.getElementById("btnOpenShortcuts");

// background.js의 manifest "commands" 이름과 1:1로 맞춘 표시용 라벨 + 한줄 설명.
// [HOTKEY-EXPAND] 처음 보는 사람도 이름만으로 뭘 하는 단축키인지 알 수 있도록
// hint를 함께 보여준다(전부 COMMAND_LABELS → COMMANDS_META로 확장).
const COMMANDS_META = {
  "toggle-hotkeys-master": {
    label: "단축키 전체 켜기/끄기",
    hint: "이하 9개 단축키 전체 반응 여부",
  },
  "reset-timer": {
    label: "타이머 리셋",
    hint: "마우스 휠/R키와 동일",
  },
  "toggle-pause-timer": {
    label: "타이머 일시정지 / 재개",
    hint: "스페이스바와 동일한 3단 토글",
  },
  "toggle-snooze": {
    label: "다음 알람 한 번 건너뛰기",
    hint: "위 스누즈 체크박스와 동일",
  },
  "force-pause-media": {
    label: "미디어 지금 즉시 정지",
    hint: "알람을 기다리지 않고 바로 정지",
  },
  "force-resume-media": {
    label: "미디어 지금 즉시 재생",
    hint: "리셋을 기다리지 않고 바로 재생",
  },
  "toggle-auto-pause": {
    label: "자동 정지·재생 기능 켜기/끄기",
    hint: "맨 위 체크박스와 동일",
  },
  "seek-backward": {
    label: "동영상 되감기",
    hint: "아래 초 설정만큼 뒤로",
  },
  "seek-forward": {
    label: "동영상 넘기기",
    hint: "아래 초 설정만큼 앞으로",
  },
  "toggle-mute-media": {
    label: "동영상 음소거 켜기/끄기",
    hint: "정지 대신 소리만 끄기",
  },
  "open-preset-sites": {
    label: "등록된 사이트 한번에 실행",
    hint: "아래 '사이트 실행' 섹션에서 등록",
  },
};

// [ORDER] 위 객체 키 순서를 "기본 표시 순서"로 사용한다(수동 정렬을 아직
// 한 번도 안 했거나, 새로 추가된 커맨드가 저장된 순서에 없을 때의 기본값).
const DEFAULT_COMMAND_ORDER = Object.keys(COMMANDS_META);

if (hotkeysEnabledCheck) {
  chrome.storage.local.get(["hotkeysEnabled"], ({ hotkeysEnabled }) => {
    hotkeysEnabledCheck.checked = hotkeysEnabled !== false; // 기본값 켜짐
  });
  hotkeysEnabledCheck.addEventListener("change", () => {
    chrome.storage.local.set({ hotkeysEnabled: hotkeysEnabledCheck.checked });
  });
}

// [LAST-USED] background.js가 chrome.commands.onCommand마다 기록해두는
// commandLastUsed[command] = 타임스탬프(ms)를 "N분 전" 같은 문구로 바꾼다.
// 다음작업.md 3번 항목: 이 값이 안 바뀌면 "다른 프로그램이 먼저 키를
// 가로챘을 가능성"을 사용자가 간접적으로 알 수 있다.
function formatLastUsed(ts) {
  if (!ts) return "아직 사용 안 함";
  const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (diffSec < 60) return "방금 전 사용";
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `마지막 사용: ${diffMin}분 전`;
  const diffHour = Math.floor(diffMin / 60);
  if (diffHour < 24) return `마지막 사용: ${diffHour}시간 전`;
  const diffDay = Math.floor(diffHour / 24);
  return `마지막 사용: ${diffDay}일 전`;
}

// [ORDER] 저장된 표시 순서(commandsOrder)를 읽어온다. 저장된 적 없거나 새
// 커맨드가 섞여 있으면 DEFAULT_COMMAND_ORDER를 기준으로 보충한다.
async function getCommandsOrder() {
  const { commandsOrder } = await chrome.storage.local.get(["commandsOrder"]);
  const stored = Array.isArray(commandsOrder) ? commandsOrder : [];
  const known = new Set(DEFAULT_COMMAND_ORDER);
  const cleaned = stored.filter((name) => known.has(name));
  for (const name of DEFAULT_COMMAND_ORDER) {
    if (!cleaned.includes(name)) cleaned.push(name);
  }
  return cleaned;
}

async function setCommandsOrder(order) {
  await chrome.storage.local.set({ commandsOrder: order });
}

// [HOTKEY] chrome.commands.getAll()로 지금 실제 바인딩된 키 조합을 읽어와 보여준다.
// 키를 캡처하는 UI가 아니라 "지금 뭐로 설정돼 있는지 보여주기"까지만 — 실제 변경은
// chrome://extensions/shortcuts에서만 가능(크롬 자체 제약, 확장프로그램이 우회 불가).
// [ORDER] 표시 순서는 사용자가 드래그로 저장한 commandsOrder를 기본으로 쓰고,
// "배정된 것만 위로" 옵션이 켜져 있으면 그 순서를 유지한 채 배정된 것 / 안 된
// 것 두 그룹으로만 재정렬한다(수동 정렬과 충돌하지 않도록 그룹 내부 순서는 유지).
async function renderCommands() {
  if (!commandsListEl) return;
  const [commands, order, assignedFirst, { commandLastUsed = {} }] =
    await Promise.all([
      chrome.commands.getAll(),
      getCommandsOrder(),
      chrome.storage.local.get(["commandsAssignedFirst"]).then(
        (r) => r.commandsAssignedFirst === true
      ),
      chrome.storage.local.get(["commandLastUsed"]),
    ]);

  const byName = new Map(commands.map((c) => [c.name, c]));
  let names = order.filter((name) => COMMANDS_META[name]);

  if (assignedFirst) {
    const assigned = names.filter((n) => byName.get(n)?.shortcut);
    const unassigned = names.filter((n) => !byName.get(n)?.shortcut);
    names = [...assigned, ...unassigned];
  }

  commandsListEl.innerHTML = names
    .map((name) => {
      const c = byName.get(name);
      const meta = COMMANDS_META[name];
      const shortcut = c?.shortcut || "(설정 안 됨)";
      const badgeClass = c?.shortcut ? "badge" : "badge title";
      const lastUsedText = formatLastUsed(commandLastUsed[name]);
      return `
        <div class="tab-row" draggable="true" data-command="${escapeHtml(name)}">
          <span class="drag-handle" title="드래그해서 순서 변경" style="cursor:grab; color:#a1a1aa; flex-shrink:0;">⠿</span>
          <div class="tab-info">
            <div class="tab-title">${escapeHtml(meta.label)}</div>
            <div class="tab-domain">${escapeHtml(meta.hint)} · ${escapeHtml(lastUsedText)}</div>
          </div>
          <span class="${badgeClass}">${escapeHtml(shortcut)}</span>
        </div>`;
    })
    .join("");

  wireCommandDragAndDrop();
}

// [ORDER] 순수 HTML5 draggable 속성만 사용(외부 라이브러리 불필요, 다음작업.md
// 6번 항목의 요구사항). 드롭 대상 행의 위/아래 절반 중 어디에 놓였는지로
// 삽입 위치를 정한다. 표시 순서만 바뀔 뿐 실제 chrome.commands 등록과는 무관.
function wireCommandDragAndDrop() {
  if (!commandsListEl) return;
  let draggedName = null;

  commandsListEl.querySelectorAll(".tab-row[data-command]").forEach((row) => {
    row.addEventListener("dragstart", () => {
      draggedName = row.dataset.command;
      row.style.opacity = "0.5";
    });
    row.addEventListener("dragend", () => {
      row.style.opacity = "";
    });
    row.addEventListener("dragover", (e) => {
      e.preventDefault();
    });
    row.addEventListener("drop", async (e) => {
      e.preventDefault();
      const targetName = row.dataset.command;
      if (!draggedName || draggedName === targetName) return;

      const rect = row.getBoundingClientRect();
      const insertAfter = e.clientY - rect.top > rect.height / 2;

      const order = await getCommandsOrder();
      const fromIndex = order.indexOf(draggedName);
      if (fromIndex !== -1) order.splice(fromIndex, 1);
      let toIndex = order.indexOf(targetName);
      if (toIndex === -1) toIndex = order.length;
      if (insertAfter) toIndex += 1;
      order.splice(toIndex, 0, draggedName);

      await setCommandsOrder(order);
      await renderCommands();
    });
  });
}

// [ORDER] "배정된 것만 위로 모아보기" 토글.
const assignedFirstCheck = document.getElementById("assignedFirstCheck");
if (assignedFirstCheck) {
  chrome.storage.local.get(["commandsAssignedFirst"], ({ commandsAssignedFirst }) => {
    assignedFirstCheck.checked = commandsAssignedFirst === true;
  });
  assignedFirstCheck.addEventListener("change", () => {
    chrome.storage.local.set(
      { commandsAssignedFirst: assignedFirstCheck.checked },
      renderCommands
    );
  });
}

// [SEEK] 되감기/넘기기 이동 초(1~60초, 기본 5초). background.js의
// getSeekSeconds()가 그대로 읽어가는 storage.local.seekSeconds 키를 공유한다.
const seekSecondsInput = document.getElementById("seekSecondsInput");
if (seekSecondsInput) {
  chrome.storage.local.get(["seekSeconds"], ({ seekSeconds }) => {
    const val = Number(seekSeconds);
    seekSecondsInput.value = Number.isFinite(val) && val > 0 ? val : 5;
  });
  seekSecondsInput.addEventListener("change", () => {
    let val = Number(seekSecondsInput.value);
    if (!Number.isFinite(val) || val < 1) val = 1;
    if (val > 60) val = 60;
    seekSecondsInput.value = val;
    chrome.storage.local.set({ seekSeconds: val });
  });
}

if (btnOpenShortcuts) {
  btnOpenShortcuts.addEventListener("click", () => {
    // chrome.commands.openShortcutSettings()는 Chrome에서 지원하지 않아
    // (Firefox 전용 API) tabs.create로 직접 연다.
    chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
  });
}

renderCommands();

// ---- [DISPATCH-SEEK] 사이트 자체 방향키로 되감기/넘기기 (선택 사이트) -----
// storage.local.dispatchSeekDomains: 문자열 도메인 배열. background.js의
// seekAllMediaInPage()가 이 목록에 있는 도메인의 탭에서만 currentTime 직접 조작
// 대신 그 사이트 자체 ←/→ 단축키를 흉내낸 KeyboardEvent를 dispatch한다.
// 등록/삭제 UI는 기존 프리셋 사이트(presetSites) 관리 패턴을 그대로 재사용한다.
const dispatchSeekListEl = document.getElementById("dispatchSeekList");
const dispatchSeekActiveRowEl = document.getElementById(
  "dispatchSeekActiveRow"
);
const dispatchSeekDomainInputEl = document.getElementById(
  "dispatchSeekDomainInput"
);
const btnAddDispatchSeekDomain = document.getElementById(
  "btnAddDispatchSeekDomain"
);

async function getDispatchSeekDomains() {
  const { dispatchSeekDomains } = await chrome.storage.local.get([
    "dispatchSeekDomains",
  ]);
  return Array.isArray(dispatchSeekDomains) ? dispatchSeekDomains : [];
}

async function setDispatchSeekDomains(domains) {
  await chrome.storage.local.set({ dispatchSeekDomains: domains });
}

function renderDispatchSeekList(domains) {
  if (!dispatchSeekListEl) return;
  if (domains.length === 0) {
    dispatchSeekListEl.innerHTML = `<div class="empty">등록된 사이트가 없습니다 (모든 사이트에 위 초 설정이 적용됩니다).</div>`;
    return;
  }
  dispatchSeekListEl.innerHTML = domains
    .map(
      (d, i) => `
        <div class="tab-row">
          <div class="tab-info">
            <div class="tab-title">${escapeHtml(d)}</div>
          </div>
          <button class="btn remove" data-remove-dispatch-domain="${i}">삭제</button>
        </div>`
    )
    .join("");

  dispatchSeekListEl
    .querySelectorAll("[data-remove-dispatch-domain]")
    .forEach((btn) => {
      btn.addEventListener("click", async () => {
        const domains = await getDispatchSeekDomains();
        domains.splice(Number(btn.dataset.removeDispatchDomain), 1);
        await setDispatchSeekDomains(domains);
        renderDispatchSeekList(domains);
        renderDispatchSeekActiveRow();
      });
    });
}

// 현재 보고 있는 탭의 도메인을 버튼 한 번으로 바로 추가할 수 있는 행.
// 위 "제어 대상 탭"의 renderActiveTabQuickAdd와 동일한 목적/패턴이지만,
// 여기서는 도메인만 다루므로(제목 기준 없음) 별도로 둔다.
async function renderDispatchSeekActiveRow() {
  if (!dispatchSeekActiveRowEl) return;
  const activeTab = await getActiveTab();
  if (!activeTab || !isControllableTab(activeTab)) {
    dispatchSeekActiveRowEl.innerHTML = `<div class="empty">이 탭은 추가할 수 없습니다. (일반 웹사이트 탭에서만 가능)</div>`;
    return;
  }
  const domain = getDomain(activeTab.url);
  const domains = await getDispatchSeekDomains();
  if (!domain || domains.includes(domain)) {
    dispatchSeekActiveRowEl.innerHTML = domain
      ? `<div class="empty">현재 사이트(${escapeHtml(
          domain
        )})는 이미 등록되어 있습니다.</div>`
      : "";
    return;
  }
  dispatchSeekActiveRowEl.innerHTML = `
    <div class="tab-row">
      <div class="tab-info">
        <div class="tab-title">${escapeHtml(domain)}</div>
        <div class="tab-domain">현재 보고 있는 사이트</div>
      </div>
      <button class="btn" id="btnAddActiveDispatchDomain">추가</button>
    </div>`;
  const btn = document.getElementById("btnAddActiveDispatchDomain");
  if (btn) {
    btn.addEventListener("click", async () => {
      const latest = await getDispatchSeekDomains();
      if (!latest.includes(domain)) latest.push(domain);
      await setDispatchSeekDomains(latest);
      renderDispatchSeekList(latest);
      renderDispatchSeekActiveRow();
    });
  }
}

if (btnAddDispatchSeekDomain && dispatchSeekDomainInputEl) {
  btnAddDispatchSeekDomain.addEventListener("click", async () => {
    // 사용자가 "https://netflix.com/watch/123" 처럼 전체 URL을 붙여넣어도
    // 도메인만 뽑아 저장한다(host.endsWith 매칭 로직과 형식을 맞추기 위함).
    const raw = dispatchSeekDomainInputEl.value
      .trim()
      .replace(/^https?:\/\//i, "")
      .replace(/\/.*$/, "");
    if (!raw) return;
    const domains = await getDispatchSeekDomains();
    if (!domains.includes(raw)) domains.push(raw);
    await setDispatchSeekDomains(domains);
    dispatchSeekDomainInputEl.value = "";
    renderDispatchSeekList(domains);
    renderDispatchSeekActiveRow();
  });
  dispatchSeekDomainInputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") btnAddDispatchSeekDomain.click();
  });
}

getDispatchSeekDomains().then(renderDispatchSeekList);
renderDispatchSeekActiveRow();

// ---- 탭 선택/매칭 UI ----------------------------------------------------

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "";
  }
}

function isControllableTab(tab) {
  return !!tab.id && /^https?:/.test(tab.url || "");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// 팝업을 연 시점에 사용자가 보고 있던(현재 활성) 탭을 가져온다.
// (요구사항 3: 열린 탭 목록에서 찾는 것보다 "지금 이 탭" 바로 추가가 더 빠름)
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

// ---- [12] 제어 대상 탭 - 포함/제외 모드 ---------------------------------
// background.js의 resolveTargetTabs()가 함께 읽는 storage.session.targetsMode와
// 동일한 키를 공유한다("include" 기본값 | "exclude").

const targetsModeIncludeRadio = document.getElementById("targetsModeInclude");
const targetsModeExcludeRadio = document.getElementById("targetsModeExclude");
const targetsModeHintEl = document.getElementById("targetsModeHint");
const selectedListTitleEl = document.getElementById("selectedListTitle");

async function getTargetsMode() {
  const { targetsMode } = await chrome.storage.session.get(["targetsMode"]);
  return targetsMode === "exclude" ? "exclude" : "include";
}

async function setTargetsMode(mode) {
  await chrome.storage.session.set({ targetsMode: mode });
}

function updateTargetsModeUI(mode) {
  if (targetsModeHintEl) {
    targetsModeHintEl.textContent =
      mode === "exclude"
        ? "선택 안 하면 제외되는 탭이 없어 결국 전체 탭이 대상입니다(포함 모드와 결과는 같음)."
        : "선택 안 하면 전체 탭이 대상입니다(기본값).";
  }
  if (selectedListTitleEl) {
    selectedListTitleEl.textContent =
      mode === "exclude" ? "제외된 탭" : "선택된 탭";
  }
}

if (targetsModeIncludeRadio && targetsModeExcludeRadio) {
  [targetsModeIncludeRadio, targetsModeExcludeRadio].forEach((radio) => {
    radio.addEventListener("change", async () => {
      const mode = targetsModeExcludeRadio.checked ? "exclude" : "include";
      await setTargetsMode(mode);
      updateTargetsModeUI(mode);
      await renderAll();
    });
  });
}

// ---- [7] 사이트 실행 단축키 (프리셋) 관리 UI -----------------------------
// background.js의 openPresetSites()/getPresetSites()가 함께 읽는
// storage.local.presetSites(URL 문자열 배열), presetSitesIncognito(불리언)를
// 그대로 공유한다.

const presetSitesListEl = document.getElementById("presetSitesList");
const presetSiteInputEl = document.getElementById("presetSiteInput");
const btnAddPresetSite = document.getElementById("btnAddPresetSite");
const presetIncognitoCheck = document.getElementById("presetIncognitoCheck");
const presetIncognitoStatusEl = document.getElementById("presetIncognitoStatus");
const btnOpenExtensionsIncognito = document.getElementById(
  "btnOpenExtensionsIncognito"
);
const btnTestOpenPresetSites = document.getElementById(
  "btnTestOpenPresetSites"
);

async function getPresetSites() {
  const { presetSites } = await chrome.storage.local.get(["presetSites"]);
  return Array.isArray(presetSites) ? presetSites : [];
}

async function setPresetSites(sites) {
  await chrome.storage.local.set({ presetSites: sites });
}

function renderPresetSites(sites) {
  if (!presetSitesListEl) return;
  if (sites.length === 0) {
    presetSitesListEl.innerHTML = `<div class="empty">등록된 사이트가 없습니다.</div>`;
    return;
  }
  presetSitesListEl.innerHTML = sites
    .map(
      (url, i) => `
        <div class="tab-row">
          <div class="tab-info">
            <div class="tab-title" title="${escapeHtml(url)}">${escapeHtml(url)}</div>
          </div>
          <button class="btn remove" data-remove-preset="${i}">삭제</button>
        </div>`
    )
    .join("");

  presetSitesListEl.querySelectorAll("[data-remove-preset]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const sites = await getPresetSites();
      sites.splice(Number(btn.dataset.removePreset), 1);
      await setPresetSites(sites);
      renderPresetSites(sites);
    });
  });
}

if (btnAddPresetSite && presetSiteInputEl) {
  btnAddPresetSite.addEventListener("click", async () => {
    const raw = presetSiteInputEl.value.trim();
    if (!raw) return;
    const sites = await getPresetSites();
    sites.push(raw);
    await setPresetSites(sites);
    presetSiteInputEl.value = "";
    renderPresetSites(sites);
  });
  presetSiteInputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") btnAddPresetSite.click();
  });
}

// [7] "시크릿 모드로 열기" 체크박스. 실제로 시크릿 창을 열 수 있으려면 Chrome
// 정책상 사용자가 "확장 프로그램 관리"에서 "시크릿 모드에서 허용"을 직접 켜야
// 하며, 코드로는 그 권한을 요청하거나 우회할 수 없다. 여기서는 현재 허용
// 여부를 확인해 안내문/버튼만 보여준다.
async function refreshIncognitoStatus() {
  if (!presetIncognitoStatusEl) return;
  const allowed = await chrome.extension.isAllowedIncognitoAccess();
  if (allowed) {
    presetIncognitoStatusEl.textContent =
      "시크릿 모드 허용이 켜져 있어 바로 사용할 수 있습니다.";
    if (btnOpenExtensionsIncognito) btnOpenExtensionsIncognito.style.display = "none";
  } else {
    presetIncognitoStatusEl.textContent =
      '시크릿 창으로 열려면 먼저 확장 프로그램 관리에서 "시크릿 모드에서 허용"을 켜야 합니다.';
    if (btnOpenExtensionsIncognito) btnOpenExtensionsIncognito.style.display = "";
  }
}

if (presetIncognitoCheck) {
  chrome.storage.local.get(["presetSitesIncognito"], ({ presetSitesIncognito }) => {
    presetIncognitoCheck.checked = presetSitesIncognito === true;
    refreshIncognitoStatus();
  });
  presetIncognitoCheck.addEventListener("change", () => {
    chrome.storage.local.set(
      { presetSitesIncognito: presetIncognitoCheck.checked },
      refreshIncognitoStatus
    );
  });
}

if (btnOpenExtensionsIncognito) {
  btnOpenExtensionsIncognito.addEventListener("click", () => {
    chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` });
  });
}

if (btnTestOpenPresetSites) {
  btnTestOpenPresetSites.addEventListener("click", async () => {
    btnTestOpenPresetSites.disabled = true;
    const result = await chrome.runtime.sendMessage({
      type: "MAPLE_TIMER_OPEN_PRESET_SITES",
    });
    btnTestOpenPresetSites.disabled = false;
    if (result?.ok) return;
    if (result?.reason === "empty") {
      alert("등록된 사이트가 없습니다. 먼저 사이트를 추가해주세요.");
    } else if (result?.reason === "incognito_not_allowed") {
      alert(
        '시크릿 창으로 열려면 먼저 확장 프로그램 관리에서 "시크릿 모드에서 허용"을 켜야 합니다. 안내 화면을 열어드릴게요.'
      );
      chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` });
    }
  });
}

getPresetSites().then(renderPresetSites);

async function getSelectedTargets() {
  const { selectedTargets } = await chrome.storage.session.get([
    "selectedTargets",
  ]);
  return selectedTargets || [];
}

async function setSelectedTargets(targets) {
  await chrome.storage.session.set({ selectedTargets: targets });
}

async function addTarget(tab, matchBy) {
  const targets = await getSelectedTargets();
  targets.push({
    tabId: tab.id,
    domain: getDomain(tab.url),
    titleAtSelection: tab.title || "",
    matchBy, // "domain" | "title"
  });
  await setSelectedTargets(targets);
  await renderAll();
}

async function removeTarget(index) {
  const targets = await getSelectedTargets();
  targets.splice(index, 1);
  await setSelectedTargets(targets);
  await renderAll();
}

// 현재 활성 탭을 "도메인" 또는 "제목" 버튼 한 번으로 바로 추가할 수 있는 행을 그린다.
// 이미 선택된 탭이거나 제어 불가능한 탭(chrome:// 등)이면 안내 문구만 보여준다.
function renderActiveTabQuickAdd(activeTab, selectedTabIds) {
  if (!activeTabRowEl) return;

  if (!activeTab || !isControllableTab(activeTab)) {
    activeTabRowEl.innerHTML = `<div class="empty">이 탭은 추가할 수 없습니다. (일반 웹사이트 탭에서만 가능)</div>`;
    return;
  }

  if (selectedTabIds.has(activeTab.id)) {
    activeTabRowEl.innerHTML = `<div class="empty">현재 탭은 이미 대상으로 선택되어 있습니다.</div>`;
    return;
  }

  const favicon = activeTab.favIconUrl || "";
  activeTabRowEl.innerHTML = `
    <div class="tab-row">
      ${favicon ? `<img src="${escapeHtml(favicon)}" alt="">` : ""}
      <div class="tab-info">
        <div class="tab-title" title="${escapeHtml(activeTab.title || "")}">${escapeHtml(
    activeTab.title || "(제목 없음)"
  )}</div>
        <div class="tab-domain">${escapeHtml(getDomain(activeTab.url))}</div>
      </div>
      <button class="btn" id="btnAddActiveDomain">도메인</button>
      <button class="btn" id="btnAddActiveTitle">제목</button>
    </div>`;

  const domainBtn = document.getElementById("btnAddActiveDomain");
  const titleBtn = document.getElementById("btnAddActiveTitle");
  if (domainBtn) domainBtn.addEventListener("click", () => addTarget(activeTab, "domain"));
  if (titleBtn) titleBtn.addEventListener("click", () => addTarget(activeTab, "title"));
}

// ---- 지금 정지된 탭 목록 -------------------------------------------------
// [PAUSED-LIST] background.js가 관리하는 chrome.storage.session의 pausedTabIds를
// 그대로 읽어와서, 배지 숫자만으로는 알 수 없는 "어떤 탭이 정지됐는지"를
// 팝업에서 확인할 수 있게 한다. 탭이 그 사이 닫혔으면 "(닫힌 탭)"으로 표시.

async function getPausedTabIds() {
  const { pausedTabIds } = await chrome.storage.session.get([
    "pausedTabIds",
  ]);
  return pausedTabIds || [];
}

function renderPausedTabs(allTabs, pausedTabIds) {
  if (pausedCountEl) pausedCountEl.textContent = String(pausedTabIds.length);
  if (!pausedListEl) return;

  if (pausedTabIds.length === 0) {
    pausedListEl.innerHTML = `<div class="empty">지금 정지된 탭이 없습니다.</div>`;
    return;
  }

  const tabById = new Map(allTabs.map((t) => [t.id, t]));
  pausedListEl.innerHTML = pausedTabIds
    .map((id) => {
      const tab = tabById.get(id);
      if (!tab) {
        return `
          <div class="tab-row">
            <div class="tab-info">
              <div class="tab-title">(닫힌 탭)</div>
            </div>
            <span class="badge paused">정지됨</span>
          </div>`;
      }
      const favicon = tab.favIconUrl || "";
      return `
        <div class="tab-row">
          ${favicon ? `<img src="${escapeHtml(favicon)}" alt="">` : ""}
          <div class="tab-info">
            <div class="tab-title" title="${escapeHtml(tab.title || "")}">${escapeHtml(
        tab.title || "(제목 없음)"
      )}</div>
            <div class="tab-domain">${escapeHtml(getDomain(tab.url))}</div>
          </div>
          <span class="badge paused">정지됨</span>
          <button class="btn" data-resume-tab="${tab.id}">지금 재생</button>
        </div>`;
    })
    .join("");

  // [11] 리셋을 기다리지 않고 이 탭 하나만 지금 바로 재생. background.js의
  // resumeSingleTab()이 pausedTabIds에서 이 탭만 제거하고 배지도 갱신해준다.
  pausedListEl.querySelectorAll("[data-resume-tab]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      await chrome.runtime.sendMessage({
        type: "MAPLE_TIMER_RESUME_SINGLE_TAB",
        tabId: Number(btn.dataset.resumeTab),
      });
      await renderAll();
    });
  });
}

async function renderAll() {
  const [tabs, targets, activeTab, pausedTabIds, targetsMode] =
    await Promise.all([
      chrome.tabs.query({}),
      getSelectedTargets(),
      getActiveTab(),
      getPausedTabIds(),
      getTargetsMode(),
    ]);
  const controllableTabs = tabs.filter(isControllableTab);
  const selectedTabIds = new Set(targets.map((t) => t.tabId));

  // [12] 팝업을 열 때마다(또는 라디오 변경 시) 저장된 모드로 라디오/안내문을 맞춘다.
  if (targetsModeIncludeRadio && targetsModeExcludeRadio) {
    targetsModeIncludeRadio.checked = targetsMode === "include";
    targetsModeExcludeRadio.checked = targetsMode === "exclude";
  }
  updateTargetsModeUI(targetsMode);

  renderActiveTabQuickAdd(activeTab, selectedTabIds);
  renderPausedTabs(tabs, pausedTabIds);

  // [SNOOZE] 팝업을 열 때마다 최신 상태로 다시 맞춘다(백그라운드에서 이미
  // 소모되어 꺼져 있을 수 있으므로).
  if (snoozeCheck) {
    const { snoozeNextAlarm } = await chrome.storage.session.get([
      "snoozeNextAlarm",
    ]);
    snoozeCheck.checked = !!snoozeNextAlarm;
  }

  // 선택된 대상 목록
  if (targets.length === 0) {
    selectedListEl.innerHTML = `<div class="empty">선택된 탭 없음 (전체 탭 대상)</div>`;
  } else {
    selectedListEl.innerHTML = targets
      .map((t, i) => {
        const badgeClass = t.matchBy === "title" ? "badge title" : "badge";
        const badgeText = t.matchBy === "title" ? "제목" : "도메인";
        const label =
          t.matchBy === "title" ? t.titleAtSelection : t.domain;
        return `
          <div class="tab-row">
            <div class="tab-info">
              <div class="tab-title" title="${escapeHtml(
                t.titleAtSelection
              )}">${escapeHtml(label || "(알 수 없음)")}</div>
              <div class="tab-domain">${escapeHtml(t.domain)}</div>
            </div>
            <span class="${badgeClass}">${badgeText}</span>
            <button class="btn remove" data-remove-index="${i}">삭제</button>
          </div>`;
      })
      .join("");

    selectedListEl.querySelectorAll("[data-remove-index]").forEach((btn) => {
      btn.addEventListener("click", () => {
        removeTarget(Number(btn.dataset.removeIndex));
      });
    });
  }

  // 추가 가능한(아직 선택 안 된) 탭 목록. 현재 활성 탭은 위 "빠르게 추가"
  // 행에서 이미 다루므로 중복으로 보이지 않게 제외한다.
  const candidates = controllableTabs.filter(
    (t) => !selectedTabIds.has(t.id) && !(activeTab && t.id === activeTab.id)
  );

  if (candidates.length === 0) {
    candidateListEl.innerHTML = `<div class="empty">추가할 수 있는 탭이 없습니다.</div>`;
  } else {
    candidateListEl.innerHTML = candidates
      .map((t) => {
        const favicon = t.favIconUrl || "";
        return `
          <div class="tab-row">
            ${
              favicon
                ? `<img src="${escapeHtml(favicon)}" alt="">`
                : ""
            }
            <div class="tab-info">
              <div class="tab-title" title="${escapeHtml(t.title || "")}">${escapeHtml(
          t.title || "(제목 없음)"
        )}</div>
              <div class="tab-domain">${escapeHtml(getDomain(t.url))}</div>
            </div>
            <button class="btn" data-add-domain="${t.id}">도메인</button>
            <button class="btn" data-add-title="${t.id}">제목</button>
          </div>`;
      })
      .join("");

    const tabById = new Map(candidates.map((t) => [t.id, t]));

    candidateListEl.querySelectorAll("[data-add-domain]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = tabById.get(Number(btn.dataset.addDomain));
        if (tab) addTarget(tab, "domain");
      });
    });
    candidateListEl.querySelectorAll("[data-add-title]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = tabById.get(Number(btn.dataset.addTitle));
        if (tab) addTarget(tab, "title");
      });
    });
  }
}

renderAll();
