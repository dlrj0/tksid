const check = document.getElementById("enabledCheck");
const status = document.getElementById("status");
const selectedListEl = document.getElementById("selectedList");
const candidateListEl = document.getElementById("candidateList");
const activeTabRowEl = document.getElementById("activeTabRow");
const snoozeCheck = document.getElementById("snoozeCheck");
const pausedListEl = document.getElementById("pausedList");
const pausedCountEl = document.getElementById("pausedCount");

// ---- 켜짐/꺼짐 토글 (기존 기능) ----------------------------------------

chrome.storage.local.get(["enabled"], ({ enabled }) => {
  check.checked = enabled !== false; // 기본값 true
  renderStatus();
});

check.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: check.checked }, async () => {
    renderStatus();
    // [BADGE] 꺼지는 순간 배지를 바로 비우고, 켜지는 순간엔 이미 정지되어 있던
    // 탭 수를 즉시 반영한다(다음 알람/리셋을 기다릴 필요 없이 아이콘이 바로 맞아야 함).
    if (!check.checked) {
      chrome.action.setBadgeText({ text: "" });
    } else {
      const { pausedTabIds = [] } = await chrome.storage.session.get([
        "pausedTabIds",
      ]);
      chrome.action.setBadgeText({
        text: pausedTabIds.length > 0 ? String(pausedTabIds.length) : "",
      });
    }
  });
});

function renderStatus() {
  status.textContent = check.checked
    ? "켜짐: 알람이 울리면 선택한 탭(또는 전체 탭)의 영상이 자동으로 멈추고, 리셋되면 다시 재생됩니다."
    : "꺼짐: 자동 정지/재생 기능이 비활성화되었습니다.";
}

// ---- 스누즈(다음 알람 한 번 건너뛰기) -----------------------------------
// [SNOOZE] chrome.storage.session에 저장하는 1회성 플래그. background.js의
// handleAlarm()이 알람을 처리할 때 이 값을 확인해 true면 이번 알람만 건너뛰고
// 스스로 false로 되돌린다(소모성). 그래서 팝업을 다시 열 때마다 최신 상태를
// 다시 읽어와야 하며(이미 소모됐을 수 있으므로), renderAll()에서 매번 갱신한다.
if (snoozeCheck) {
  chrome.storage.session.get(["snoozeNextAlarm"], ({ snoozeNextAlarm }) => {
    snoozeCheck.checked = !!snoozeNextAlarm;
  });

  snoozeCheck.addEventListener("change", () => {
    chrome.storage.session.set({ snoozeNextAlarm: snoozeCheck.checked });
  });
}

// ---- 탭 선택/매칭 UI ----------------------------------------------------

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "";
  }
}

function isControllableTab(tab) {
  return !!tab.id && /^https?:/.test(tab.url || "");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// 팝업을 연 시점에 사용자가 보고 있던(현재 활성) 탭을 가져온다.
// (요구사항 3: 열린 탭 목록에서 찾는 것보다 "지금 이 탭" 바로 추가가 더 빠름)
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function getSelectedTargets() {
  const { selectedTargets } = await chrome.storage.session.get([
    "selectedTargets",
  ]);
  return selectedTargets || [];
}

async function setSelectedTargets(targets) {
  await chrome.storage.session.set({ selectedTargets: targets });
}

async function addTarget(tab, matchBy) {
  const targets = await getSelectedTargets();
  targets.push({
    tabId: tab.id,
    domain: getDomain(tab.url),
    titleAtSelection: tab.title || "",
    matchBy, // "domain" | "title"
  });
  await setSelectedTargets(targets);
  await renderAll();
}

async function removeTarget(index) {
  const targets = await getSelectedTargets();
  targets.splice(index, 1);
  await setSelectedTargets(targets);
  await renderAll();
}

// 현재 활성 탭을 "도메인" 또는 "제목" 버튼 한 번으로 바로 추가할 수 있는 행을 그린다.
// 이미 선택된 탭이거나 제어 불가능한 탭(chrome:// 등)이면 안내 문구만 보여준다.
function renderActiveTabQuickAdd(activeTab, selectedTabIds) {
  if (!activeTabRowEl) return;

  if (!activeTab || !isControllableTab(activeTab)) {
    activeTabRowEl.innerHTML = `<div class="empty">이 탭은 추가할 수 없습니다. (일반 웹사이트 탭에서만 가능)</div>`;
    return;
  }

  if (selectedTabIds.has(activeTab.id)) {
    activeTabRowEl.innerHTML = `<div class="empty">현재 탭은 이미 대상으로 선택되어 있습니다.</div>`;
    return;
  }

  const favicon = activeTab.favIconUrl || "";
  activeTabRowEl.innerHTML = `
    <div class="tab-row">
      ${favicon ? `<img src="${escapeHtml(favicon)}" alt="">` : ""}
      <div class="tab-info">
        <div class="tab-title" title="${escapeHtml(activeTab.title || "")}">${escapeHtml(
    activeTab.title || "(제목 없음)"
  )}</div>
        <div class="tab-domain">${escapeHtml(getDomain(activeTab.url))}</div>
      </div>
      <button class="btn" id="btnAddActiveDomain">도메인</button>
      <button class="btn" id="btnAddActiveTitle">제목</button>
    </div>`;

  const domainBtn = document.getElementById("btnAddActiveDomain");
  const titleBtn = document.getElementById("btnAddActiveTitle");
  if (domainBtn) domainBtn.addEventListener("click", () => addTarget(activeTab, "domain"));
  if (titleBtn) titleBtn.addEventListener("click", () => addTarget(activeTab, "title"));
}

// ---- 지금 정지된 탭 목록 -------------------------------------------------
// [PAUSED-LIST] background.js가 관리하는 chrome.storage.session의 pausedTabIds를
// 그대로 읽어와서, 배지 숫자만으로는 알 수 없는 "어떤 탭이 정지됐는지"를
// 팝업에서 확인할 수 있게 한다. 탭이 그 사이 닫혔으면 "(닫힌 탭)"으로 표시.

async function getPausedTabIds() {
  const { pausedTabIds } = await chrome.storage.session.get([
    "pausedTabIds",
  ]);
  return pausedTabIds || [];
}

function renderPausedTabs(allTabs, pausedTabIds) {
  if (pausedCountEl) pausedCountEl.textContent = String(pausedTabIds.length);
  if (!pausedListEl) return;

  if (pausedTabIds.length === 0) {
    pausedListEl.innerHTML = `<div class="empty">지금 정지된 탭이 없습니다.</div>`;
    return;
  }

  const tabById = new Map(allTabs.map((t) => [t.id, t]));
  pausedListEl.innerHTML = pausedTabIds
    .map((id) => {
      const tab = tabById.get(id);
      if (!tab) {
        return `
          <div class="tab-row">
            <div class="tab-info">
              <div class="tab-title">(닫힌 탭)</div>
            </div>
            <span class="badge paused">정지됨</span>
          </div>`;
      }
      const favicon = tab.favIconUrl || "";
      return `
        <div class="tab-row">
          ${favicon ? `<img src="${escapeHtml(favicon)}" alt="">` : ""}
          <div class="tab-info">
            <div class="tab-title" title="${escapeHtml(tab.title || "")}">${escapeHtml(
        tab.title || "(제목 없음)"
      )}</div>
            <div class="tab-domain">${escapeHtml(getDomain(tab.url))}</div>
          </div>
          <span class="badge paused">정지됨</span>
        </div>`;
    })
    .join("");
}

async function renderAll() {
  const [tabs, targets, activeTab, pausedTabIds] = await Promise.all([
    chrome.tabs.query({}),
    getSelectedTargets(),
    getActiveTab(),
    getPausedTabIds(),
  ]);
  const controllableTabs = tabs.filter(isControllableTab);
  const selectedTabIds = new Set(targets.map((t) => t.tabId));

  renderActiveTabQuickAdd(activeTab, selectedTabIds);
  renderPausedTabs(tabs, pausedTabIds);

  // [SNOOZE] 팝업을 열 때마다 최신 상태로 다시 맞춘다(백그라운드에서 이미
  // 소모되어 꺼져 있을 수 있으므로).
  if (snoozeCheck) {
    const { snoozeNextAlarm } = await chrome.storage.session.get([
      "snoozeNextAlarm",
    ]);
    snoozeCheck.checked = !!snoozeNextAlarm;
  }

  // 선택된 대상 목록
  if (targets.length === 0) {
    selectedListEl.innerHTML = `<div class="empty">선택된 탭 없음 (전체 탭 대상)</div>`;
  } else {
    selectedListEl.innerHTML = targets
      .map((t, i) => {
        const badgeClass = t.matchBy === "title" ? "badge title" : "badge";
        const badgeText = t.matchBy === "title" ? "제목" : "도메인";
        const label =
          t.matchBy === "title" ? t.titleAtSelection : t.domain;
        return `
          <div class="tab-row">
            <div class="tab-info">
              <div class="tab-title" title="${escapeHtml(
                t.titleAtSelection
              )}">${escapeHtml(label || "(알 수 없음)")}</div>
              <div class="tab-domain">${escapeHtml(t.domain)}</div>
            </div>
            <span class="${badgeClass}">${badgeText}</span>
            <button class="btn remove" data-remove-index="${i}">삭제</button>
          </div>`;
      })
      .join("");

    selectedListEl.querySelectorAll("[data-remove-index]").forEach((btn) => {
      btn.addEventListener("click", () => {
        removeTarget(Number(btn.dataset.removeIndex));
      });
    });
  }

  // 추가 가능한(아직 선택 안 된) 탭 목록. 현재 활성 탭은 위 "빠르게 추가"
  // 행에서 이미 다루므로 중복으로 보이지 않게 제외한다.
  const candidates = controllableTabs.filter(
    (t) => !selectedTabIds.has(t.id) && !(activeTab && t.id === activeTab.id)
  );

  if (candidates.length === 0) {
    candidateListEl.innerHTML = `<div class="empty">추가할 수 있는 탭이 없습니다.</div>`;
  } else {
    candidateListEl.innerHTML = candidates
      .map((t) => {
        const favicon = t.favIconUrl || "";
        return `
          <div class="tab-row">
            ${
              favicon
                ? `<img src="${escapeHtml(favicon)}" alt="">`
                : ""
            }
            <div class="tab-info">
              <div class="tab-title" title="${escapeHtml(t.title || "")}">${escapeHtml(
          t.title || "(제목 없음)"
        )}</div>
              <div class="tab-domain">${escapeHtml(getDomain(t.url))}</div>
            </div>
            <button class="btn" data-add-domain="${t.id}">도메인</button>
            <button class="btn" data-add-title="${t.id}">제목</button>
          </div>`;
      })
      .join("");

    const tabById = new Map(candidates.map((t) => [t.id, t]));

    candidateListEl.querySelectorAll("[data-add-domain]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = tabById.get(Number(btn.dataset.addDomain));
        if (tab) addTarget(tab, "domain");
      });
    });
    candidateListEl.querySelectorAll("[data-add-title]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = tabById.get(Number(btn.dataset.addTitle));
        if (tab) addTarget(tab, "title");
      });
    });
  }
}

renderAll();
