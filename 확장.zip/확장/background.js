// background.js

// 각 탭 안에서 실행되는 함수들 -----------------------------------------

function pauseAllMediaInPage() {
  // 반환값: 이 페이지에서 실제로 하나라도 정지시켰는지 여부.
  // (확장 프로그램이 "직접 정지시킨 탭"만 나중에 재생시키기 위한 추적용)
  let pausedAny = false;
  document.querySelectorAll("video, audio").forEach((m) => {
    if (!m.paused) {
      try {
        m.pause();
        pausedAny = true;
      } catch (e) {
        /* 무시 */
      }
    }
  });
  return pausedAny;
}

function playAllMediaInPage() {
  document.querySelectorAll("video, audio").forEach((m) => {
    try {
      const p = m.play();
      if (p && typeof p.catch === "function") {
        // 자동재생 정책 등으로 거부되어도 조용히 무시 (요구사항 3-4)
        p.catch(() => {});
      }
    } catch (e) {
      /* 무시 */
    }
  });
}

// 탭 선택/매칭 -----------------------------------------------------------

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "";
  }
}

function isControllableTab(tab) {
  return !!tab.id && /^https?:/.test(tab.url || "");
}

// 사용자가 선택한 대상(chrome.storage.session의 selectedTargets)을 실제 열려있는
// 탭과 매칭한다. 선택된 대상이 하나도 없으면(기본값) 열려있는 모든 http(s) 탭을 반환.
// (요구사항 B: 선택 안 하면 전체 대상 — 기존 동작 유지)
async function resolveTargetTabs(excludeTabId) {
  const allTabs = await chrome.tabs.query({});
  const candidateTabs = allTabs.filter(
    (t) => isControllableTab(t) && t.id !== excludeTabId
  );

  const { selectedTargets } = await chrome.storage.session.get([
    "selectedTargets",
  ]);

  if (!selectedTargets || selectedTargets.length === 0) {
    return candidateTabs; // 기본값: 전체 탭 대상
  }

  const resolved = new Map();
  for (const target of selectedTargets) {
    // 1순위: 저장해둔 tabId가 여전히 열려있으면 그대로 사용 (가장 정확함)
    let tab = candidateTabs.find((t) => t.id === target.tabId);

    // 2순위: 새로고침 등으로 tabId가 바뀌었을 경우, 지정한 매칭 기준으로 재탐색
    // (요구사항 3-3: 탭마다 도메인/제목 중 사용자가 고른 기준으로 매칭)
    if (!tab) {
      if (target.matchBy === "title") {
        tab = candidateTabs.find((t) => t.title === target.titleAtSelection);
      } else {
        tab = candidateTabs.find((t) => getDomain(t.url) === target.domain);
      }
    }

    if (tab) resolved.set(tab.id, tab);
  }
  return Array.from(resolved.values());
}

// 메시지 처리 --------------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type === "MAPLE_TIMER_ALARM") {
    handleAlarm(sender);
  } else if (message?.type === "MAPLE_TIMER_RESET") {
    handleReset(sender);
  }
  // 비동기 응답이 필요 없으므로 별도 return 값 없음
});

async function handleAlarm(sender) {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  if (enabled === false) return; // 기본값은 켜짐(true)

  // [SNOOZE] 팝업에서 "다음 알람 한 번 건너뛰기"를 켜둔 경우, 이번 알람에서는
  // 미디어를 정지시키지 않고 플래그를 소모(1회성)한 뒤 종료한다. 확장 프로그램
  // 전체를 끄지 않고도 잠깐 건너뛸 수 있게 하기 위함.
  const { snoozeNextAlarm } = await chrome.storage.session.get([
    "snoozeNextAlarm",
  ]);
  if (snoozeNextAlarm) {
    await chrome.storage.session.set({ snoozeNextAlarm: false });
    return;
  }

  const tabs = await resolveTargetTabs(sender?.tab?.id);
  const newlyPausedIds = [];

  for (const tab of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: pauseAllMediaInPage,
      });
      const didPause = results?.[0]?.result === true;
      if (didPause) newlyPausedIds.push(tab.id);
    } catch (e) {
      /* 권한이 없는 특수 페이지 등은 조용히 무시 */
    }
  }

  if (newlyPausedIds.length > 0) {
    const { pausedTabIds = [] } = await chrome.storage.session.get([
      "pausedTabIds",
    ]);
    const merged = Array.from(new Set([...pausedTabIds, ...newlyPausedIds]));
    await chrome.storage.session.set({ pausedTabIds: merged });

    // [BADGE] 팝업을 열지 않아도 "지금 정지된 탭 수"를 확장 아이콘에서 바로 확인.
    // manifest.json에 이미 action 키가 있어 추가 권한 없이 사용 가능.
    updateBadge(merged.length);
  }
}

async function handleReset(sender) {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  if (enabled === false) return;

  // 요구사항 3-2: 확장 프로그램이 "직접 정지시킨 탭"에만 재생 신호를 보냄.
  // 사용자가 스스로 일시정지한 영상까지 강제로 재생시키지 않기 위함.
  const { pausedTabIds = [] } = await chrome.storage.session.get([
    "pausedTabIds",
  ]);
  if (pausedTabIds.length === 0) return;

  const targetTabs = await resolveTargetTabs(sender?.tab?.id);
  const targetIdSet = new Set(targetTabs.map((t) => t.id));

  for (const tabId of pausedTabIds) {
    if (!targetIdSet.has(tabId)) continue;
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: playAllMediaInPage,
      });
    } catch (e) {
      /* 탭이 닫혔거나 권한이 없는 페이지 등은 조용히 무시 */
    }
  }

  // 재생을 시도했으니(대상에서 빠져 더 이상 추적할 필요 없는 탭 포함) 추적 목록 비움.
  // 리셋마다 반복 play() 되어도 이미 재생 중인 미디어의 play()는 사실상 no-op이라
  // 문제 없음(요구사항 3-1의 검증 대상).
  await chrome.storage.session.set({ pausedTabIds: [] });

  // [BADGE] 정지된 탭이 더 이상 없으므로 배지 제거.
  updateBadge(0);
}

// 배지(badge) 표시 -----------------------------------------------------

// [BADGE] count가 0이면 배지 텍스트를 비워 아이콘을 깨끗하게 유지하고,
// 1 이상이면 그 숫자를 그대로 표시한다. 색상은 README의 --danger 톤(#ef4444)에 맞춤.
function updateBadge(count) {
  chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
}

// 확장 프로그램이 꺼져 있는 동안(handleAlarm 진입 시점에 걸러짐) 쌓였을 수 있는
// 배지, 그리고 브라우저를 재시작하면 storage.session(pausedTabIds)이 함께
// 초기화되므로 배지도 같은 시점에 비워 상태를 맞춘다.
chrome.runtime.onStartup.addListener(() => {
  chrome.action.setBadgeText({ text: "" });
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: "" });
});
