// background.js

// 각 탭 안에서 실행되는 함수들 -----------------------------------------

function pauseAllMediaInPage() {
  // 반환값: 이 페이지에서 실제로 하나라도 정지시켰는지 여부.
  // (확장 프로그램이 "직접 정지시킨 탭"만 나중에 재생시키기 위한 추적용)
  let pausedAny = false;
  document.querySelectorAll("video, audio").forEach((m) => {
    if (!m.paused) {
      try {
        m.pause();
        pausedAny = true;
      } catch (e) {
        /* 무시 */
      }
    }
  });
  return pausedAny;
}

function playAllMediaInPage() {
  document.querySelectorAll("video, audio").forEach((m) => {
    try {
      const p = m.play();
      if (p && typeof p.catch === "function") {
        // 자동재생 정책 등으로 거부되어도 조용히 무시 (요구사항 3-4)
        p.catch(() => {});
      }
    } catch (e) {
      /* 무시 */
    }
  });
}

// [SEEK] 재생 중인 video만 골라 currentTime을 이동시킨다. pauseAllMediaInPage와
// 동일한 필터(!m.paused)를 재사용 — 광고 등 숨겨진/정지된 video는 건드리지 않음.
//
// [DISPATCH-SEEK] 넷플릭스처럼 자체 DRM/MSE 플레이어를 쓰는 사이트는 video.currentTime을
// 외부에서 직접 바꿔도 내부 상태(자체 seek bar, 버퍼링 로직)가 무시하거나 되돌리는 경우가
// 있다. 이런 사이트는 currentTime 직접 조작 대신, 사이트가 이미 갖고 있는 ←/→ 방향키
// 단축키를 가짜 KeyboardEvent로 흉내내어 사이트 스스로 이동하게 만드는 편이 낫다.
// 다만 이 방식이 통하는지 여부는 사이트마다 다르고(예: isTrusted 체크로 무시할 수도 있음),
// 이동 단위도 사이트가 정한 고정값(보통 10초)이라 사용자가 설정한 seekSeconds와 정확히
// 일치하지 않는다. 그래서 전체 사이트에 일괄 적용하지 않고, 사용자가 팝업에서 직접
// 등록한 도메인(dispatchDomains)에서만 이 방식을 쓰고, 나머지는 기존 currentTime 방식을
// 그대로 유지한다(요구사항: 기존 1~60초 기능은 유지한 채 필요한 사이트만 선택 적용).
function seekAllMediaInPage(deltaSeconds, dispatchDomains) {
  const host = location.hostname;
  const useDispatch =
    Array.isArray(dispatchDomains) &&
    dispatchDomains.some((d) => host === d || host.endsWith("." + d));

  if (useDispatch) {
    const key = deltaSeconds < 0 ? "ArrowLeft" : "ArrowRight";
    const keyCode = key === "ArrowLeft" ? 37 : 39;
    // 방향키는 사이트가 정한 고정 단위(대개 10초)이므로, 설정한 초를 10으로
    // 나눈 횟수만큼 반복 입력해 근사치를 맞춘다(최소 1회).
    const presses = Math.max(1, Math.round(Math.abs(deltaSeconds) / 10));

    for (let i = 0; i < presses; i++) {
      const opts = {
        key,
        code: key,
        keyCode,
        which: keyCode,
        bubbles: true,
        cancelable: true,
      };
      document.dispatchEvent(new KeyboardEvent("keydown", opts));
      document.dispatchEvent(new KeyboardEvent("keyup", opts));
    }
    return;
  }

  document.querySelectorAll("video").forEach((v) => {
    if (!v.paused) {
      try {
        v.currentTime = Math.max(0, v.currentTime + deltaSeconds);
      } catch (e) {
        /* 무시 */
      }
    }
  });
}

// [MUTE] 현재 하나라도 소리가 켜져 있으면(음소거 아님) 전체를 음소거하고,
// 전부 음소거 상태면 전체를 해제한다(토글). video/audio 둘 다 대상.
function toggleMuteAllMediaInPage() {
  const media = document.querySelectorAll("video, audio");
  let anyUnmuted = false;
  media.forEach((m) => {
    if (!m.muted) anyUnmuted = true;
  });
  const nextMuted = anyUnmuted;
  media.forEach((m) => {
    try {
      m.muted = nextMuted;
    } catch (e) {
      /* 무시 */
    }
  });
  return nextMuted;
}

// 탭 선택/매칭 -----------------------------------------------------------

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "";
  }
}

function isControllableTab(tab) {
  return !!tab.id && /^https?:/.test(tab.url || "");
}

// [12] 선택된 대상(selectedTargets)을 실제 열려있는 탭 후보(candidateTabs) 중에서
// 찾아 tabId -> tab 맵으로 반환한다. resolveTargetTabs()가 "포함" 모드와 "제외"
// 모드 양쪽에서 공유하는 매칭 로직(기존 코드 그대로, 위치만 분리).
function matchSelectedTargets(candidateTabs, selectedTargets) {
  const resolved = new Map();
  for (const target of selectedTargets) {
    // 1순위: 저장해둔 tabId가 여전히 열려있으면 그대로 사용 (가장 정확함)
    let tab = candidateTabs.find((t) => t.id === target.tabId);

    // 2순위: 새로고침 등으로 tabId가 바뀌었을 경우, 지정한 매칭 기준으로 재탐색
    // (요구사항 3-3: 탭마다 도메인/제목 중 사용자가 고른 기준으로 매칭)
    if (!tab) {
      if (target.matchBy === "title") {
        tab = candidateTabs.find((t) => t.title === target.titleAtSelection);
      } else {
        tab = candidateTabs.find((t) => getDomain(t.url) === target.domain);
      }
    }

    if (tab) resolved.set(tab.id, tab);
  }
  return resolved;
}

// 사용자가 선택한 대상(chrome.storage.session의 selectedTargets)을 실제 열려있는
// 탭과 매칭한다. 선택된 대상이 하나도 없으면(기본값) 열려있는 모든 http(s) 탭을 반환.
// (요구사항 B: 선택 안 하면 전체 대상 — 기존 동작 유지)
// excludeTabIds: 단일 tabId, tabId 배열, 또는 생략 가능. 알람/리셋 신호를 보낸 타이머
// 탭 자신(또는 여러 타이머 탭)을 대상에서 빼기 위해 사용.
// [12] targetsMode("include" 기본값 | "exclude")에 따라 selectedTargets의 의미가
// 반전된다: "include"는 기존과 동일(선택한 것만 대상), "exclude"는 선택한 것만
// 빼고 나머지 전체가 대상이 된다. 선택된 대상이 없으면 모드와 무관하게 항상 전체
// 탭이 대상(기존 동작 그대로 유지, 다음작업.md 12번 요구사항).
async function resolveTargetTabs(excludeTabIds) {
  const excludeSet = new Set(
    Array.isArray(excludeTabIds)
      ? excludeTabIds
      : excludeTabIds != null
      ? [excludeTabIds]
      : []
  );
  const allTabs = await chrome.tabs.query({});
  const candidateTabs = allTabs.filter(
    (t) => isControllableTab(t) && !excludeSet.has(t.id)
  );

  const { selectedTargets, targetsMode } = await chrome.storage.session.get([
    "selectedTargets",
    "targetsMode",
  ]);

  if (!selectedTargets || selectedTargets.length === 0) {
    return candidateTabs; // 기본값: 전체 탭 대상 (모드와 무관)
  }

  const matched = matchSelectedTargets(candidateTabs, selectedTargets);

  if (targetsMode === "exclude") {
    // 제외 모드: 매칭된 탭들만 빼고 나머지 전체가 대상.
    return candidateTabs.filter((t) => !matched.has(t.id));
  }

  return Array.from(matched.values()); // 기존 "포함" 모드
}

// 메시지 처리 --------------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "MAPLE_TIMER_ALARM") {
    handleAlarm(sender);
  } else if (message?.type === "MAPLE_TIMER_RESET") {
    handleReset(sender);
  } else if (message?.type === "MAPLE_TIMER_PAGE_READY") {
    // [HOTKEY] 이 탭이 타이머 페이지라는 걸 스스로 알려온 것. 전역 단축키가
    // 눌렸을 때 모든 탭을 뒤지지 않고 바로 이 탭으로 메시지를 보내기 위해 기억해둔다.
    if (sender?.tab?.id != null) addTimerTabId(sender.tab.id);
  } else if (message?.type === "MAPLE_TIMER_RESUME_SINGLE_TAB") {
    // [11] 팝업의 "지금 정지된 탭" 목록에서 개별 재생 버튼이 눌렸을 때. 팝업이
    // 결과(성공 여부)를 받아 목록을 다시 그릴 수 있도록 비동기 응답이 필요하다.
    resumeSingleTab(message.tabId).then(sendResponse);
    return true; // sendResponse를 비동기로 호출할 것임을 알림
  } else if (message?.type === "MAPLE_TIMER_OPEN_PRESET_SITES") {
    // [7] 팝업에서 "지금 열기" 테스트 버튼을 눌렀을 때도 단축키와 동일한 로직 재사용.
    openPresetSites().then(sendResponse);
    return true;
  } else if (message?.type === "MAPLE_TIMER_PRESET_STORAGE") {
    // [8] 타이머 사이트(index.html)가 watcher.js를 거쳐 보낸 프리셋 저장/불러오기
    // 요청. 실제 파일 시스템 대신 chrome.storage.local을 파일처럼 사용한다
    // (다음작업.md 8번 기술 제약 참고). 페이지는 이 값을 기본 프리셋/1~4번
    // 프리셋 슬롯을 구분하는 키(예: "mesoTimerPreset_base")로 관리한다.
    handlePresetStorage(message).then(sendResponse);
    return true;
  }
  // 그 외에는 비동기 응답이 필요 없으므로 별도 return 값 없음
});

// [8] 프리셋 저장소 --------------------------------------------------------
// 페이지(index.html)는 이 메시지를 통해 기본 프리셋/1~4번 프리셋을
// chrome.storage.local에 저장하거나 불러온다. 값은 항상 JSON 문자열(state
// 전체)로 취급하며, 이 함수는 그 문자열을 그대로 저장/반환할 뿐 내용을
// 해석하지 않는다. key는 페이지 쪽에서 "mesoTimerPreset_base",
// "mesoTimerPreset_1" ~ "mesoTimerPreset_4"처럼 슬롯별로 이미 구분해서 보낸다.
async function handlePresetStorage(message) {
  const { action, key, value } = message;
  if (!key) return { value: undefined };

  if (action === "get") {
    const result = await chrome.storage.local.get([key]);
    return { value: result[key] };
  }
  if (action === "set") {
    await chrome.storage.local.set({ [key]: value });
    return { value: true };
  }
  return { value: undefined };
}

// [SHARED] 대상 탭들의 미디어를 정지시키고 pausedTabIds에 병합 기록한다.
// handleAlarm(자동 알람)과 force-pause-media(수동 단축키)가 공유.
async function pauseTargetTabs(excludeTabIds) {
  const tabs = await resolveTargetTabs(excludeTabIds);
  const newlyPausedIds = [];

  for (const tab of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: pauseAllMediaInPage,
      });
      const didPause = results?.[0]?.result === true;
      if (didPause) newlyPausedIds.push(tab.id);
    } catch (e) {
      /* 권한이 없는 특수 페이지 등은 조용히 무시 */
    }
  }

  if (newlyPausedIds.length > 0) {
    const { pausedTabIds = [] } = await chrome.storage.session.get([
      "pausedTabIds",
    ]);
    const merged = Array.from(new Set([...pausedTabIds, ...newlyPausedIds]));
    await chrome.storage.session.set({ pausedTabIds: merged });

    // [BADGE] 팝업을 열지 않아도 "지금 정지된 탭 수"를 확장 아이콘에서 바로 확인.
    updateBadge(merged.length);
  }
  return newlyPausedIds.length;
}

// [SHARED] 확장 프로그램이 직접 정지시킨 탭(pausedTabIds)만 골라 재생시킨다.
// handleReset(자동 리셋 신호)과 force-resume-media(수동 단축키)가 공유.
async function resumeTargetTabs(excludeTabIds) {
  const { pausedTabIds = [] } = await chrome.storage.session.get([
    "pausedTabIds",
  ]);
  if (pausedTabIds.length === 0) return 0;

  const targetTabs = await resolveTargetTabs(excludeTabIds);
  const targetIdSet = new Set(targetTabs.map((t) => t.id));
  let resumedCount = 0;

  for (const tabId of pausedTabIds) {
    if (!targetIdSet.has(tabId)) continue;
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: playAllMediaInPage,
      });
      resumedCount++;
    } catch (e) {
      /* 탭이 닫혔거나 권한이 없는 페이지 등은 조용히 무시 */
    }
  }

  // 재생을 시도했으니(대상에서 빠져 더 이상 추적할 필요 없는 탭 포함) 추적 목록 비움.
  // 리셋마다 반복 play() 되어도 이미 재생 중인 미디어의 play()는 사실상 no-op이라
  // 문제 없음(요구사항 3-1의 검증 대상).
  await chrome.storage.session.set({ pausedTabIds: [] });

  // [BADGE] 정지된 탭이 더 이상 없으므로 배지 제거.
  updateBadge(0);
  return resumedCount;
}

// [11] 팝업의 "지금 정지된 탭" 목록에서 탭 하나만 골라 즉시 재생시킨다.
// 전체 재생(resumeTargetTabs)과 달리 리셋 신호를 기다리지 않고, 그 탭 하나만
// pausedTabIds에서 제거한다(나머지 정지된 탭은 그대로 유지).
async function resumeSingleTab(tabId) {
  const { pausedTabIds = [] } = await chrome.storage.session.get([
    "pausedTabIds",
  ]);
  if (!pausedTabIds.includes(tabId)) return { ok: false };

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: playAllMediaInPage,
    });
  } catch (e) {
    /* 탭이 닫혔거나 권한이 없는 페이지 등은 조용히 무시 */
  }

  const next = pausedTabIds.filter((id) => id !== tabId);
  await chrome.storage.session.set({ pausedTabIds: next });
  updateBadge(next.length);
  return { ok: true };
}

// [SEEK] storage.local의 seekSeconds 설정값(팝업에서 조절, 기본 5초)을 읽는다.
async function getSeekSeconds() {
  const { seekSeconds } = await chrome.storage.local.get(["seekSeconds"]);
  const val = Number(seekSeconds);
  return Number.isFinite(val) && val > 0 ? val : 5;
}

// [DISPATCH-SEEK] storage.local의 dispatchSeekDomains(팝업에서 관리하는 도메인 문자열
// 배열)를 읽는다. 이 목록에 있는 도메인의 탭에서만 seekAllMediaInPage가 currentTime
// 대신 방향키 dispatchEvent 방식을 쓴다. 프리셋 사이트(presetSites)와 동일한 저장
// 패턴(문자열 배열)을 재사용.
async function getDispatchSeekDomains() {
  const { dispatchSeekDomains } = await chrome.storage.local.get([
    "dispatchSeekDomains",
  ]);
  return Array.isArray(dispatchSeekDomains) ? dispatchSeekDomains : [];
}

// [SEEK/MUTE] force-pause-media와 같은 패턴: resolveTargetTabs()로 대상 탭을
// 구하고(선택된 탭이 없으면 전체 탭) 각 탭에 스크립트를 주입한다. 정지 여부
// 추적(pausedTabIds)과는 무관한 즉시성 동작이라 별도 상태 저장은 하지 않는다.
async function seekTargetTabs(excludeTabIds, deltaSeconds) {
  const tabs = await resolveTargetTabs(excludeTabIds);
  const dispatchDomains = await getDispatchSeekDomains();
  for (const tab of tabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: seekAllMediaInPage,
        args: [deltaSeconds, dispatchDomains],
      });
    } catch (e) {
      /* 권한이 없는 특수 페이지 등은 조용히 무시 */
    }
  }
}

// 반환값: 대상 탭들 중 하나라도 "음소거 상태로" 전환됐으면 true. 탭마다 이전
// 음소거 상태가 다를 수 있어 완벽히 하나의 값으로 요약되진 않지만, 타이머 탭의
// 토스트/피크음 표시용으로는 충분한 근사치임(대부분 탭이 1~2개인 실사용 기준).
async function toggleMuteTargetTabs(excludeTabIds) {
  const tabs = await resolveTargetTabs(excludeTabIds);
  let anyMuted = false;
  for (const tab of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: toggleMuteAllMediaInPage,
      });
      if (results?.[0]?.result === true) anyMuted = true;
    } catch (e) {
      /* 무시 */
    }
  }
  return anyMuted;
}

// [7] 사이트 실행 단축키 --------------------------------------------------
// storage.local.presetSites: 문자열 URL 배열(팝업에서 관리).
// storage.local.presetSitesIncognito: 시크릿 창으로 열지 여부.

function normalizeUrl(raw) {
  const s = (raw || "").trim();
  if (!s) return "";
  if (/^https?:\/\//i.test(s)) return s;
  return "https://" + s;
}

async function getPresetSites() {
  const { presetSites = [] } = await chrome.storage.local.get([
    "presetSites",
  ]);
  return Array.isArray(presetSites) ? presetSites : [];
}

// 반환값으로 팝업(또는 단축키 핸들러)이 사용자에게 안내할 결과를 알려준다:
// - { ok: true }: 정상적으로 열림
// - { ok: false, reason: "empty" }: 등록된 사이트가 없음
// - { ok: false, reason: "incognito_not_allowed" }: 시크릿 모드 사용을 원하지만
//   "확장 프로그램 관리"에서 "시크릿 모드에서 허용"을 켜지 않은 상태 — 코드로
//   우회 불가(Chrome 정책), 사용자가 직접 켜야 함.
async function openPresetSites() {
  const [sites, { presetSitesIncognito }] = await Promise.all([
    getPresetSites(),
    chrome.storage.local.get(["presetSitesIncognito"]),
  ]);
  const urls = sites.map(normalizeUrl).filter(Boolean);
  if (urls.length === 0) return { ok: false, reason: "empty" };

  if (presetSitesIncognito) {
    const allowed = await chrome.extension.isAllowedIncognitoAccess();
    if (!allowed) return { ok: false, reason: "incognito_not_allowed" };
    await chrome.windows.create({ url: urls, incognito: true });
    return { ok: true };
  }

  for (const url of urls) {
    try {
      await chrome.tabs.create({ url });
    } catch (e) {
      /* 무시 */
    }
  }
  return { ok: true };
}

async function handleAlarm(sender) {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  if (enabled === false) return; // 기본값은 켜짐(true)

  // [SNOOZE] 팝업에서 "다음 알람 한 번 건너뛰기"를 켜둔 경우, 이번 알람에서는
  // 미디어를 정지시키지 않고 플래그를 소모(1회성)한 뒤 종료한다. 확장 프로그램
  // 전체를 끄지 않고도 잠깐 건너뛸 수 있게 하기 위함.
  const { snoozeNextAlarm } = await chrome.storage.session.get([
    "snoozeNextAlarm",
  ]);
  if (snoozeNextAlarm) {
    await chrome.storage.session.set({ snoozeNextAlarm: false });
    return;
  }

  await pauseTargetTabs(sender?.tab?.id);
}

async function handleReset(sender) {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  if (enabled === false) return;

  // 요구사항 3-2: 확장 프로그램이 "직접 정지시킨 탭"에만 재생 신호를 보냄.
  // 사용자가 스스로 일시정지한 영상까지 강제로 재생시키지 않기 위함.
  await resumeTargetTabs(sender?.tab?.id);
}

// 배지(badge) 표시 -----------------------------------------------------

// [BADGE] count가 0이면 배지 텍스트를 비워 아이콘을 깨끗하게 유지하고,
// 1 이상이면 그 숫자를 그대로 표시한다. 색상은 README의 --danger 톤(#ef4444)에 맞춤.
function updateBadge(count) {
  chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
}

// 전역 단축키(핫키) -----------------------------------------------------
// [HOTKEY] 창 포커스와 무관하게(=메이플이 포그라운드여도) 동작하는 10개의 전역
// 단축키를 처리한다. manifest.json의 "commands" 참고.
// - seek-backward / seek-forward: force-pause-media와 같은 패턴으로 대상 탭의
//   재생 중인 <video>.currentTime을 storage.local.seekSeconds(기본 5초)만큼
//   이동시킨다. 표준 video 속성만 다루므로 모든 사이트에 보편적으로 동작.
// - toggle-mute-media: 대상 탭 미디어의 음소거를 토글한다(정지가 아니라 음소거).
// - toggle-hotkeys-master: 아래 6개 단축키의 반응 여부를 토글하는 마스터 스위치.
//   주의: 이 토글을 꺼도 OS 레벨에서 키 조합 자체를 가로채는 건 그대로 유지된다
//   (Chrome 확장프로그램은 런타임에 단축키 등록을 해제할 수 없음). 즉 꺼두면
//   "이 확장프로그램이 반응을 안 할 뿐"이고, 그 키 조합을 다른 프로그램에서 쓰고
//   싶다면 chrome://extensions/shortcuts에서 실제로 바인딩을 빼야 한다.
// - reset-timer / toggle-pause-timer: 타이머 페이지(watcher.js)로 브릿지 메시지를
//   보내 실제 동작(fastRestart / pause·resume 토글)을 페이지 스크립트가 수행하게 한다.
// - toggle-snooze: 페이지와 무관하게 확장프로그램 저장소(snoozeNextAlarm)만 토글한다.
// - force-pause-media / force-resume-media: 알람/리셋을 기다리지 않고 지금 즉시
//   대상 탭 미디어를 정지/재생시킨다. "자동" 기능(storage.local.enabled) 여부와
//   무관하게 항상 동작 — 사용자가 지금 직접 누른 명시적 요청이기 때문.
// - toggle-auto-pause: 팝업 맨 위 체크박스와 같은 storage.local.enabled를 토글.
//   배지에 잠깐 "ON"/"OFF"를 띄워(flashBadge) 화면을 안 봐도 결과를 알 수 있게 함.

// [HOTKEY] MAPLE_TIMER_PAGE_READY 메시지를 보낸 적 있는 탭 id 목록.
// [FIX] 원래는 메모리상의 Set으로 관리했으나, MV3 서비스워커는 약 30초 동안 유휴
// 상태면 종료됐다가 다음 이벤트(단축키 등) 때 다시 깨어나며, 이때 메모리 상태는
// 전부 초기화된다. 타이머 탭은 페이지 로드 시 "저 타이머 탭이에요" 신호를 딱 한
// 번만 보내므로, 사냥 중 한참 지나 서비스워커가 한 번이라도 꺼졌다 깨면 그 신호를
// 다시 받을 수 없어 background가 타이머 탭 위치를 영영 모르는 상태가 되어 리셋/
// 일시정지 단축키가 먹통이 될 수 있었다. 이를 막기 위해 pausedTabIds/
// selectedTargets와 같은 패턴으로 chrome.storage.session에 저장한다
// (서비스워커가 꺼졌다 깨도 유지되고, 브라우저를 완전히 끄면 초기화됨).
async function getTimerTabIds() {
  const { timerTabIds = [] } = await chrome.storage.session.get([
    "timerTabIds",
  ]);
  return timerTabIds;
}

async function addTimerTabId(tabId) {
  const ids = await getTimerTabIds();
  if (!ids.includes(tabId)) {
    ids.push(tabId);
    await chrome.storage.session.set({ timerTabIds: ids });
  }
}

async function removeTimerTabId(tabId) {
  const ids = await getTimerTabIds();
  const next = ids.filter((id) => id !== tabId);
  if (next.length !== ids.length) {
    await chrome.storage.session.set({ timerTabIds: next });
  }
}

chrome.tabs.onRemoved.addListener((tabId) => {
  removeTimerTabId(tabId);
});

// [LAST-USED] 단축키가 실제로 chrome.commands.onCommand까지 도달했을 때마다
// (마스터 스위치 꺼짐으로 무시되는 경우는 제외) 발동 시각을 기록해둔다. 팝업의
// 단축키 목록에서 "마지막 사용: N분 전"으로 보여줘서, 키 입력이 이 확장프로그램
// 까지 가로채졌는지(다른 프로그램이 먼저 가로채지 않았는지)를 사용자가 간접
// 확인할 수 있게 한다.
async function recordCommandUsed(command) {
  const { commandLastUsed = {} } = await chrome.storage.local.get([
    "commandLastUsed",
  ]);
  commandLastUsed[command] = Date.now();
  await chrome.storage.local.set({ commandLastUsed });
}

async function getHotkeysEnabled() {
  const { hotkeysEnabled } = await chrome.storage.local.get(["hotkeysEnabled"]);
  return hotkeysEnabled !== false; // 기본값 켜짐(true)
}

// [HOTKEY] 등록된 모든 타이머 탭에 브릿지 메시지를 보낸다. 탭이 그 사이 닫혔거나
// 새로고침 중이라 content script가 아직 없는 경우는 조용히 무시(정리는
// chrome.tabs.onRemoved가 담당).
async function sendToTimerTabs(type, extra = {}) {
  const ids = await getTimerTabIds();
  for (const tabId of ids) {
    try {
      await chrome.tabs.sendMessage(tabId, { type, ...extra });
    } catch (e) {
      /* 무시 */
    }
  }
}

// [HOTKEY-BADGE] 단축키가 꺼져 있으면 회색 "OFF" 배지로 눈에 띄게 표시하고,
// 켜져 있으면 기존 "정지된 탭 수" 배지로 되돌린다.
async function refreshBadgeForHotkeyState(enabled) {
  if (!enabled) {
    chrome.action.setBadgeBackgroundColor({ color: "#71717a" });
    chrome.action.setBadgeText({ text: "OFF" });
    return;
  }
  const { pausedTabIds = [] } = await chrome.storage.session.get(["pausedTabIds"]);
  updateBadge(pausedTabIds.length);
}

// [FEEDBACK] 화면(메이플)을 보고 있어서 배지를 바로 확인하기 어려운 상황을 고려해,
// 토글류 단축키(자동 정지/재생 on-off 등) 결과를 잠깐 배지 텍스트/색으로 보여준 뒤
// durationMs 후 원래 상태(정지된 탭 수 또는 단축키 OFF 표시)로 되돌린다. 정식 배지
// 상태를 덮어쓰지 않도록 항상 refreshBadgeForHotkeyState로 복귀시킨다.
async function flashBadge(text, color, durationMs = 1200) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(async () => {
    await refreshBadgeForHotkeyState(await getHotkeysEnabled());
  }, durationMs);
}

chrome.commands.onCommand.addListener(async (command) => {
  // [LAST-USED] 마스터 스위치 상태와 무관하게 "키 입력이 이 확장프로그램에
  // 도달했다"는 사실 자체를 기록한다(마스터가 꺼져 있어 동작은 무시되더라도
  // 가로채기 자체는 확인해줄 수 있어야 하므로).
  await recordCommandUsed(command);

  if (command === "toggle-hotkeys-master") {
    const next = !(await getHotkeysEnabled());
    await chrome.storage.local.set({ hotkeysEnabled: next });
    await refreshBadgeForHotkeyState(next);
    // 마스터 토글 자체는 켜짐/꺼짐 상태와 무관하게 항상 피드백 소리를 재생해서
    // 지금 어떤 상태로 바뀌었는지 화면을 안 봐도 알 수 있게 한다.
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_MASTER_TOGGLE", { enabled: next });
    return;
  }

  if (!(await getHotkeysEnabled())) return; // 마스터 스위치가 꺼져있으면 나머지는 무시

  if (command === "reset-timer") {
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_RESET");
  } else if (command === "toggle-pause-timer") {
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_TOGGLE_PAUSE");
  } else if (command === "toggle-snooze") {
    const { snoozeNextAlarm } = await chrome.storage.session.get(["snoozeNextAlarm"]);
    const next = !snoozeNextAlarm;
    await chrome.storage.session.set({ snoozeNextAlarm: next });
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_SNOOZE_TOGGLE", { enabled: next });
  } else if (command === "force-pause-media") {
    // [HOTKEY] "자동" 정지/재생(storage.local.enabled)이 꺼져 있어도 이건 사용자가
    // 지금 직접 누른 명시적 요청이므로 그 설정과 무관하게 항상 수행한다.
    const timerIds = await getTimerTabIds();
    await pauseTargetTabs(timerIds);
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_FORCE_PAUSE");
  } else if (command === "force-resume-media") {
    const timerIds = await getTimerTabIds();
    await resumeTargetTabs(timerIds);
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_FORCE_RESUME");
  } else if (command === "toggle-auto-pause") {
    // 알람/리셋에 자동으로 반응하는 기능 전체(팝업 맨 위 체크박스와 동일한 설정) on/off.
    const { enabled } = await chrome.storage.local.get(["enabled"]);
    const next = enabled === false; // 현재 꺼짐이면 다음은 켜짐
    await chrome.storage.local.set({ enabled: next });
    await flashBadge(next ? "ON" : "OFF", next ? "#3b82f6" : "#a1a1aa");
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_AUTO_TOGGLE", { enabled: next });
  } else if (command === "seek-backward") {
    // [SEEK] "자동" 기능 설정과 무관하게 항상 동작(사용자가 지금 직접 누른 요청).
    const timerIds = await getTimerTabIds();
    const seconds = await getSeekSeconds();
    await seekTargetTabs(timerIds, -seconds);
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_SEEK_BACKWARD");
  } else if (command === "seek-forward") {
    const timerIds = await getTimerTabIds();
    const seconds = await getSeekSeconds();
    await seekTargetTabs(timerIds, seconds);
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_SEEK_FORWARD");
  } else if (command === "toggle-mute-media") {
    const timerIds = await getTimerTabIds();
    const nowMuted = await toggleMuteTargetTabs(timerIds);
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_MUTE_TOGGLE", { enabled: nowMuted });
  } else if (command === "open-preset-sites") {
    // [7] "자동" 기능 설정과 무관하게 항상 동작(사용자가 지금 직접 누른 요청).
    const result = await openPresetSites();
    if (result.ok) {
      await flashBadge("OPEN", "#3b82f6");
    } else if (result.reason === "incognito_not_allowed") {
      // 코드로 시크릿 모드 권한을 우회할 수 없으므로(Chrome 정책), 사용자가
      // 직접 켜도록 확장 프로그램 관리 화면으로 안내한다.
      await chrome.tabs.create({
        url: `chrome://extensions/?id=${chrome.runtime.id}`,
      });
      await flashBadge("🔒", "#ef4444", 2000);
    } else {
      // 등록된 사이트가 없음 — 팝업에서 먼저 추가해야 함을 배지로 살짝 알림.
      await flashBadge("!", "#a1a1aa");
    }
  }
});

// 확장 프로그램이 꺼져 있는 동안(handleAlarm 진입 시점에 걸러짐) 쌓였을 수 있는
// 배지, 그리고 브라우저를 재시작하면 storage.session(pausedTabIds)이 함께
// 초기화되므로 배지도 같은 시점에 비워 상태를 맞춘다.
// [HOTKEY] hotkeysEnabled는 storage.local이라 재시작해도 유지되므로, 꺼져 있던
// 상태였다면 시작하자마자 "OFF" 배지를 다시 보여준다.
chrome.runtime.onStartup.addListener(async () => {
  await refreshBadgeForHotkeyState(await getHotkeysEnabled());
});
chrome.runtime.onInstalled.addListener(async () => {
  await refreshBadgeForHotkeyState(await getHotkeysEnabled());
});
