// background.js

// 각 탭 안에서 실행되는 함수들 -----------------------------------------

function pauseAllMediaInPage() {
  // 반환값: 이 페이지에서 실제로 하나라도 정지시켰는지 여부.
  // (확장 프로그램이 "직접 정지시킨 탭"만 나중에 재생시키기 위한 추적용)
  let pausedAny = false;
  document.querySelectorAll("video, audio").forEach((m) => {
    if (!m.paused) {
      try {
        m.pause();
        pausedAny = true;
      } catch (e) {
        /* 무시 */
      }
    }
  });
  return pausedAny;
}

function playAllMediaInPage() {
  document.querySelectorAll("video, audio").forEach((m) => {
    try {
      const p = m.play();
      if (p && typeof p.catch === "function") {
        // 자동재생 정책 등으로 거부되어도 조용히 무시 (요구사항 3-4)
        p.catch(() => {});
      }
    } catch (e) {
      /* 무시 */
    }
  });
}

// 탭 선택/매칭 -----------------------------------------------------------

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "";
  }
}

function isControllableTab(tab) {
  return !!tab.id && /^https?:/.test(tab.url || "");
}

// 사용자가 선택한 대상(chrome.storage.session의 selectedTargets)을 실제 열려있는
// 탭과 매칭한다. 선택된 대상이 하나도 없으면(기본값) 열려있는 모든 http(s) 탭을 반환.
// (요구사항 B: 선택 안 하면 전체 대상 — 기존 동작 유지)
// excludeTabIds: 단일 tabId, tabId 배열, 또는 생략 가능. 알람/리셋 신호를 보낸 타이머
// 탭 자신(또는 여러 타이머 탭)을 대상에서 빼기 위해 사용.
async function resolveTargetTabs(excludeTabIds) {
  const excludeSet = new Set(
    Array.isArray(excludeTabIds)
      ? excludeTabIds
      : excludeTabIds != null
      ? [excludeTabIds]
      : []
  );
  const allTabs = await chrome.tabs.query({});
  const candidateTabs = allTabs.filter(
    (t) => isControllableTab(t) && !excludeSet.has(t.id)
  );

  const { selectedTargets } = await chrome.storage.session.get([
    "selectedTargets",
  ]);

  if (!selectedTargets || selectedTargets.length === 0) {
    return candidateTabs; // 기본값: 전체 탭 대상
  }

  const resolved = new Map();
  for (const target of selectedTargets) {
    // 1순위: 저장해둔 tabId가 여전히 열려있으면 그대로 사용 (가장 정확함)
    let tab = candidateTabs.find((t) => t.id === target.tabId);

    // 2순위: 새로고침 등으로 tabId가 바뀌었을 경우, 지정한 매칭 기준으로 재탐색
    // (요구사항 3-3: 탭마다 도메인/제목 중 사용자가 고른 기준으로 매칭)
    if (!tab) {
      if (target.matchBy === "title") {
        tab = candidateTabs.find((t) => t.title === target.titleAtSelection);
      } else {
        tab = candidateTabs.find((t) => getDomain(t.url) === target.domain);
      }
    }

    if (tab) resolved.set(tab.id, tab);
  }
  return Array.from(resolved.values());
}

// 메시지 처리 --------------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type === "MAPLE_TIMER_ALARM") {
    handleAlarm(sender);
  } else if (message?.type === "MAPLE_TIMER_RESET") {
    handleReset(sender);
  } else if (message?.type === "MAPLE_TIMER_PAGE_READY") {
    // [HOTKEY] 이 탭이 타이머 페이지라는 걸 스스로 알려온 것. 전역 단축키가
    // 눌렸을 때 모든 탭을 뒤지지 않고 바로 이 탭으로 메시지를 보내기 위해 기억해둔다.
    if (sender?.tab?.id != null) addTimerTabId(sender.tab.id);
  }
  // 비동기 응답이 필요 없으므로 별도 return 값 없음
});

// [SHARED] 대상 탭들의 미디어를 정지시키고 pausedTabIds에 병합 기록한다.
// handleAlarm(자동 알람)과 force-pause-media(수동 단축키)가 공유.
async function pauseTargetTabs(excludeTabIds) {
  const tabs = await resolveTargetTabs(excludeTabIds);
  const newlyPausedIds = [];

  for (const tab of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: pauseAllMediaInPage,
      });
      const didPause = results?.[0]?.result === true;
      if (didPause) newlyPausedIds.push(tab.id);
    } catch (e) {
      /* 권한이 없는 특수 페이지 등은 조용히 무시 */
    }
  }

  if (newlyPausedIds.length > 0) {
    const { pausedTabIds = [] } = await chrome.storage.session.get([
      "pausedTabIds",
    ]);
    const merged = Array.from(new Set([...pausedTabIds, ...newlyPausedIds]));
    await chrome.storage.session.set({ pausedTabIds: merged });

    // [BADGE] 팝업을 열지 않아도 "지금 정지된 탭 수"를 확장 아이콘에서 바로 확인.
    updateBadge(merged.length);
  }
  return newlyPausedIds.length;
}

// [SHARED] 확장 프로그램이 직접 정지시킨 탭(pausedTabIds)만 골라 재생시킨다.
// handleReset(자동 리셋 신호)과 force-resume-media(수동 단축키)가 공유.
async function resumeTargetTabs(excludeTabIds) {
  const { pausedTabIds = [] } = await chrome.storage.session.get([
    "pausedTabIds",
  ]);
  if (pausedTabIds.length === 0) return 0;

  const targetTabs = await resolveTargetTabs(excludeTabIds);
  const targetIdSet = new Set(targetTabs.map((t) => t.id));
  let resumedCount = 0;

  for (const tabId of pausedTabIds) {
    if (!targetIdSet.has(tabId)) continue;
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: playAllMediaInPage,
      });
      resumedCount++;
    } catch (e) {
      /* 탭이 닫혔거나 권한이 없는 페이지 등은 조용히 무시 */
    }
  }

  // 재생을 시도했으니(대상에서 빠져 더 이상 추적할 필요 없는 탭 포함) 추적 목록 비움.
  // 리셋마다 반복 play() 되어도 이미 재생 중인 미디어의 play()는 사실상 no-op이라
  // 문제 없음(요구사항 3-1의 검증 대상).
  await chrome.storage.session.set({ pausedTabIds: [] });

  // [BADGE] 정지된 탭이 더 이상 없으므로 배지 제거.
  updateBadge(0);
  return resumedCount;
}

async function handleAlarm(sender) {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  if (enabled === false) return; // 기본값은 켜짐(true)

  // [SNOOZE] 팝업에서 "다음 알람 한 번 건너뛰기"를 켜둔 경우, 이번 알람에서는
  // 미디어를 정지시키지 않고 플래그를 소모(1회성)한 뒤 종료한다. 확장 프로그램
  // 전체를 끄지 않고도 잠깐 건너뛸 수 있게 하기 위함.
  const { snoozeNextAlarm } = await chrome.storage.session.get([
    "snoozeNextAlarm",
  ]);
  if (snoozeNextAlarm) {
    await chrome.storage.session.set({ snoozeNextAlarm: false });
    return;
  }

  await pauseTargetTabs(sender?.tab?.id);
}

async function handleReset(sender) {
  const { enabled } = await chrome.storage.local.get(["enabled"]);
  if (enabled === false) return;

  // 요구사항 3-2: 확장 프로그램이 "직접 정지시킨 탭"에만 재생 신호를 보냄.
  // 사용자가 스스로 일시정지한 영상까지 강제로 재생시키지 않기 위함.
  await resumeTargetTabs(sender?.tab?.id);
}

// 배지(badge) 표시 -----------------------------------------------------

// [BADGE] count가 0이면 배지 텍스트를 비워 아이콘을 깨끗하게 유지하고,
// 1 이상이면 그 숫자를 그대로 표시한다. 색상은 README의 --danger 톤(#ef4444)에 맞춤.
function updateBadge(count) {
  chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
}

// 전역 단축키(핫키) -----------------------------------------------------
// [HOTKEY] 창 포커스와 무관하게(=메이플이 포그라운드여도) 동작하는 7개의 전역
// 단축키를 처리한다. manifest.json의 "commands" 참고.
// - toggle-hotkeys-master: 아래 6개 단축키의 반응 여부를 토글하는 마스터 스위치.
//   주의: 이 토글을 꺼도 OS 레벨에서 키 조합 자체를 가로채는 건 그대로 유지된다
//   (Chrome 확장프로그램은 런타임에 단축키 등록을 해제할 수 없음). 즉 꺼두면
//   "이 확장프로그램이 반응을 안 할 뿐"이고, 그 키 조합을 다른 프로그램에서 쓰고
//   싶다면 chrome://extensions/shortcuts에서 실제로 바인딩을 빼야 한다.
// - reset-timer / toggle-pause-timer: 타이머 페이지(watcher.js)로 브릿지 메시지를
//   보내 실제 동작(fastRestart / pause·resume 토글)을 페이지 스크립트가 수행하게 한다.
// - toggle-snooze: 페이지와 무관하게 확장프로그램 저장소(snoozeNextAlarm)만 토글한다.
// - force-pause-media / force-resume-media: 알람/리셋을 기다리지 않고 지금 즉시
//   대상 탭 미디어를 정지/재생시킨다. "자동" 기능(storage.local.enabled) 여부와
//   무관하게 항상 동작 — 사용자가 지금 직접 누른 명시적 요청이기 때문.
// - toggle-auto-pause: 팝업 맨 위 체크박스와 같은 storage.local.enabled를 토글.
//   배지에 잠깐 "ON"/"OFF"를 띄워(flashBadge) 화면을 안 봐도 결과를 알 수 있게 함.

// [HOTKEY] MAPLE_TIMER_PAGE_READY 메시지를 보낸 적 있는 탭 id 목록.
// [FIX] 원래는 메모리상의 Set으로 관리했으나, MV3 서비스워커는 약 30초 동안 유휴
// 상태면 종료됐다가 다음 이벤트(단축키 등) 때 다시 깨어나며, 이때 메모리 상태는
// 전부 초기화된다. 타이머 탭은 페이지 로드 시 "저 타이머 탭이에요" 신호를 딱 한
// 번만 보내므로, 사냥 중 한참 지나 서비스워커가 한 번이라도 꺼졌다 깨면 그 신호를
// 다시 받을 수 없어 background가 타이머 탭 위치를 영영 모르는 상태가 되어 리셋/
// 일시정지 단축키가 먹통이 될 수 있었다. 이를 막기 위해 pausedTabIds/
// selectedTargets와 같은 패턴으로 chrome.storage.session에 저장한다
// (서비스워커가 꺼졌다 깨도 유지되고, 브라우저를 완전히 끄면 초기화됨).
async function getTimerTabIds() {
  const { timerTabIds = [] } = await chrome.storage.session.get([
    "timerTabIds",
  ]);
  return timerTabIds;
}

async function addTimerTabId(tabId) {
  const ids = await getTimerTabIds();
  if (!ids.includes(tabId)) {
    ids.push(tabId);
    await chrome.storage.session.set({ timerTabIds: ids });
  }
}

async function removeTimerTabId(tabId) {
  const ids = await getTimerTabIds();
  const next = ids.filter((id) => id !== tabId);
  if (next.length !== ids.length) {
    await chrome.storage.session.set({ timerTabIds: next });
  }
}

chrome.tabs.onRemoved.addListener((tabId) => {
  removeTimerTabId(tabId);
});

async function getHotkeysEnabled() {
  const { hotkeysEnabled } = await chrome.storage.local.get(["hotkeysEnabled"]);
  return hotkeysEnabled !== false; // 기본값 켜짐(true)
}

// [HOTKEY] 등록된 모든 타이머 탭에 브릿지 메시지를 보낸다. 탭이 그 사이 닫혔거나
// 새로고침 중이라 content script가 아직 없는 경우는 조용히 무시(정리는
// chrome.tabs.onRemoved가 담당).
async function sendToTimerTabs(type, extra = {}) {
  const ids = await getTimerTabIds();
  for (const tabId of ids) {
    try {
      await chrome.tabs.sendMessage(tabId, { type, ...extra });
    } catch (e) {
      /* 무시 */
    }
  }
}

// [HOTKEY-BADGE] 단축키가 꺼져 있으면 회색 "OFF" 배지로 눈에 띄게 표시하고,
// 켜져 있으면 기존 "정지된 탭 수" 배지로 되돌린다.
async function refreshBadgeForHotkeyState(enabled) {
  if (!enabled) {
    chrome.action.setBadgeBackgroundColor({ color: "#71717a" });
    chrome.action.setBadgeText({ text: "OFF" });
    return;
  }
  const { pausedTabIds = [] } = await chrome.storage.session.get(["pausedTabIds"]);
  updateBadge(pausedTabIds.length);
}

// [FEEDBACK] 화면(메이플)을 보고 있어서 배지를 바로 확인하기 어려운 상황을 고려해,
// 토글류 단축키(자동 정지/재생 on-off 등) 결과를 잠깐 배지 텍스트/색으로 보여준 뒤
// durationMs 후 원래 상태(정지된 탭 수 또는 단축키 OFF 표시)로 되돌린다. 정식 배지
// 상태를 덮어쓰지 않도록 항상 refreshBadgeForHotkeyState로 복귀시킨다.
async function flashBadge(text, color, durationMs = 1200) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(async () => {
    await refreshBadgeForHotkeyState(await getHotkeysEnabled());
  }, durationMs);
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "toggle-hotkeys-master") {
    const next = !(await getHotkeysEnabled());
    await chrome.storage.local.set({ hotkeysEnabled: next });
    await refreshBadgeForHotkeyState(next);
    // 마스터 토글 자체는 켜짐/꺼짐 상태와 무관하게 항상 피드백 소리를 재생해서
    // 지금 어떤 상태로 바뀌었는지 화면을 안 봐도 알 수 있게 한다.
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_MASTER_TOGGLE", { enabled: next });
    return;
  }

  if (!(await getHotkeysEnabled())) return; // 마스터 스위치가 꺼져있으면 나머지는 무시

  if (command === "reset-timer") {
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_RESET");
  } else if (command === "toggle-pause-timer") {
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_TOGGLE_PAUSE");
  } else if (command === "toggle-snooze") {
    const { snoozeNextAlarm } = await chrome.storage.session.get(["snoozeNextAlarm"]);
    const next = !snoozeNextAlarm;
    await chrome.storage.session.set({ snoozeNextAlarm: next });
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_SNOOZE_TOGGLE", { enabled: next });
  } else if (command === "force-pause-media") {
    // [HOTKEY] "자동" 정지/재생(storage.local.enabled)이 꺼져 있어도 이건 사용자가
    // 지금 직접 누른 명시적 요청이므로 그 설정과 무관하게 항상 수행한다.
    const timerIds = await getTimerTabIds();
    await pauseTargetTabs(timerIds);
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_FORCE_PAUSE");
  } else if (command === "force-resume-media") {
    const timerIds = await getTimerTabIds();
    await resumeTargetTabs(timerIds);
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_FORCE_RESUME");
  } else if (command === "toggle-auto-pause") {
    // 알람/리셋에 자동으로 반응하는 기능 전체(팝업 맨 위 체크박스와 동일한 설정) on/off.
    const { enabled } = await chrome.storage.local.get(["enabled"]);
    const next = enabled === false; // 현재 꺼짐이면 다음은 켜짐
    await chrome.storage.local.set({ enabled: next });
    await flashBadge(next ? "ON" : "OFF", next ? "#3b82f6" : "#a1a1aa");
    await sendToTimerTabs("MAPLE_TIMER_HOTKEY_AUTO_TOGGLE", { enabled: next });
  }
});

// 확장 프로그램이 꺼져 있는 동안(handleAlarm 진입 시점에 걸러짐) 쌓였을 수 있는
// 배지, 그리고 브라우저를 재시작하면 storage.session(pausedTabIds)이 함께
// 초기화되므로 배지도 같은 시점에 비워 상태를 맞춘다.
// [HOTKEY] hotkeysEnabled는 storage.local이라 재시작해도 유지되므로, 꺼져 있던
// 상태였다면 시작하자마자 "OFF" 배지를 다시 보여준다.
chrome.runtime.onStartup.addListener(async () => {
  await refreshBadgeForHotkeyState(await getHotkeysEnabled());
});
chrome.runtime.onInstalled.addListener(async () => {
  await refreshBadgeForHotkeyState(await getHotkeysEnabled());
});
