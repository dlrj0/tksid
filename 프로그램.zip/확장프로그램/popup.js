const check = document.getElementById("enabledCheck");
const status = document.getElementById("status");
const selectedListEl = document.getElementById("selectedList");
const candidateListEl = document.getElementById("candidateList");
const activeTabRowEl = document.getElementById("activeTabRow");

// ---- 켜짐/꺼짐 토글 (기존 기능) ----------------------------------------

chrome.storage.local.get(["enabled"], ({ enabled }) => {
  check.checked = enabled !== false; // 기본값 true
  renderStatus();
});

check.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: check.checked }, renderStatus);
});

function renderStatus() {
  status.textContent = check.checked
    ? "켜짐: 알람이 울리면 선택한 탭(또는 전체 탭)의 영상이 자동으로 멈추고, 리셋되면 다시 재생됩니다."
    : "꺼짐: 자동 정지/재생 기능이 비활성화되었습니다.";
}

// ---- 탭 선택/매칭 UI ----------------------------------------------------

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch (e) {
    return "";
  }
}

function isControllableTab(tab) {
  return !!tab.id && /^https?:/.test(tab.url || "");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// 팝업을 연 시점에 사용자가 보고 있던(현재 활성) 탭을 가져온다.
// (요구사항 3: 열린 탭 목록에서 찾는 것보다 "지금 이 탭" 바로 추가가 더 빠름)
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function getSelectedTargets() {
  const { selectedTargets } = await chrome.storage.session.get([
    "selectedTargets",
  ]);
  return selectedTargets || [];
}

async function setSelectedTargets(targets) {
  await chrome.storage.session.set({ selectedTargets: targets });
}

async function addTarget(tab, matchBy) {
  const targets = await getSelectedTargets();
  targets.push({
    tabId: tab.id,
    domain: getDomain(tab.url),
    titleAtSelection: tab.title || "",
    matchBy, // "domain" | "title"
  });
  await setSelectedTargets(targets);
  await renderAll();
}

async function removeTarget(index) {
  const targets = await getSelectedTargets();
  targets.splice(index, 1);
  await setSelectedTargets(targets);
  await renderAll();
}

// 현재 활성 탭을 "도메인" 또는 "제목" 버튼 한 번으로 바로 추가할 수 있는 행을 그린다.
// 이미 선택된 탭이거나 제어 불가능한 탭(chrome:// 등)이면 안내 문구만 보여준다.
function renderActiveTabQuickAdd(activeTab, selectedTabIds) {
  if (!activeTabRowEl) return;

  if (!activeTab || !isControllableTab(activeTab)) {
    activeTabRowEl.innerHTML = `<div class="empty">이 탭은 추가할 수 없습니다. (일반 웹사이트 탭에서만 가능)</div>`;
    return;
  }

  if (selectedTabIds.has(activeTab.id)) {
    activeTabRowEl.innerHTML = `<div class="empty">현재 탭은 이미 대상으로 선택되어 있습니다.</div>`;
    return;
  }

  const favicon = activeTab.favIconUrl || "";
  activeTabRowEl.innerHTML = `
    <div class="tab-row">
      ${favicon ? `<img src="${escapeHtml(favicon)}" alt="">` : ""}
      <div class="tab-info">
        <div class="tab-title" title="${escapeHtml(activeTab.title || "")}">${escapeHtml(
    activeTab.title || "(제목 없음)"
  )}</div>
        <div class="tab-domain">${escapeHtml(getDomain(activeTab.url))}</div>
      </div>
      <button class="btn" id="btnAddActiveDomain">도메인</button>
      <button class="btn" id="btnAddActiveTitle">제목</button>
    </div>`;

  const domainBtn = document.getElementById("btnAddActiveDomain");
  const titleBtn = document.getElementById("btnAddActiveTitle");
  if (domainBtn) domainBtn.addEventListener("click", () => addTarget(activeTab, "domain"));
  if (titleBtn) titleBtn.addEventListener("click", () => addTarget(activeTab, "title"));
}

async function renderAll() {
  const [tabs, targets, activeTab] = await Promise.all([
    chrome.tabs.query({}),
    getSelectedTargets(),
    getActiveTab(),
  ]);
  const controllableTabs = tabs.filter(isControllableTab);
  const selectedTabIds = new Set(targets.map((t) => t.tabId));

  renderActiveTabQuickAdd(activeTab, selectedTabIds);

  // 선택된 대상 목록
  if (targets.length === 0) {
    selectedListEl.innerHTML = `<div class="empty">선택된 탭 없음 (전체 탭 대상)</div>`;
  } else {
    selectedListEl.innerHTML = targets
      .map((t, i) => {
        const badgeClass = t.matchBy === "title" ? "badge title" : "badge";
        const badgeText = t.matchBy === "title" ? "제목" : "도메인";
        const label =
          t.matchBy === "title" ? t.titleAtSelection : t.domain;
        return `
          <div class="tab-row">
            <div class="tab-info">
              <div class="tab-title" title="${escapeHtml(
                t.titleAtSelection
              )}">${escapeHtml(label || "(알 수 없음)")}</div>
              <div class="tab-domain">${escapeHtml(t.domain)}</div>
            </div>
            <span class="${badgeClass}">${badgeText}</span>
            <button class="btn remove" data-remove-index="${i}">삭제</button>
          </div>`;
      })
      .join("");

    selectedListEl.querySelectorAll("[data-remove-index]").forEach((btn) => {
      btn.addEventListener("click", () => {
        removeTarget(Number(btn.dataset.removeIndex));
      });
    });
  }

  // 추가 가능한(아직 선택 안 된) 탭 목록. 현재 활성 탭은 위 "빠르게 추가"
  // 행에서 이미 다루므로 중복으로 보이지 않게 제외한다.
  const candidates = controllableTabs.filter(
    (t) => !selectedTabIds.has(t.id) && !(activeTab && t.id === activeTab.id)
  );

  if (candidates.length === 0) {
    candidateListEl.innerHTML = `<div class="empty">추가할 수 있는 탭이 없습니다.</div>`;
  } else {
    candidateListEl.innerHTML = candidates
      .map((t) => {
        const favicon = t.favIconUrl || "";
        return `
          <div class="tab-row">
            ${
              favicon
                ? `<img src="${escapeHtml(favicon)}" alt="">`
                : ""
            }
            <div class="tab-info">
              <div class="tab-title" title="${escapeHtml(t.title || "")}">${escapeHtml(
          t.title || "(제목 없음)"
        )}</div>
              <div class="tab-domain">${escapeHtml(getDomain(t.url))}</div>
            </div>
            <button class="btn" data-add-domain="${t.id}">도메인</button>
            <button class="btn" data-add-title="${t.id}">제목</button>
          </div>`;
      })
      .join("");

    const tabById = new Map(candidates.map((t) => [t.id, t]));

    candidateListEl.querySelectorAll("[data-add-domain]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = tabById.get(Number(btn.dataset.addDomain));
        if (tab) addTarget(tab, "domain");
      });
    });
    candidateListEl.querySelectorAll("[data-add-title]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tab = tabById.get(Number(btn.dataset.addTitle));
        if (tab) addTarget(tab, "title");
      });
    });
  }
}

renderAll();
