// watcher.js
// 이 스크립트는 열려 있는 "모든" 탭에 삽입되지만,
// 실제로는 MesoTimer 페이지(#timerDisplay 요소가 있는 페이지)에서만 동작합니다.

(function () {
  const isTimerPage = !!document.getElementById("timerDisplay");
  if (!isTimerPage) return; // 타이머 페이지가 아니면 아무 것도 하지 않음

  let wasAlarming = false;
  // [RESET-SIGNAL] index.html의 notifyReset()이 body에 찍는, 1씩 증가하는 카운터.
  // 값이 바뀔 때마다(리셋이 발생할 때마다) 재생 신호를 보냄.
  let lastResetSeq = document.body ? document.body.getAttribute("data-reset-seq") : null;

  function checkAlarmState() {
    const body = document.body;
    if (!body) return;
    const isAlarming = body.classList.contains("alarm-state");

    // 알람이 "꺼짐 -> 켜짐"으로 바뀌는 순간에만 신호를 보냄 (정지 신호)
    if (isAlarming && !wasAlarming) {
      chrome.runtime.sendMessage({ type: "MAPLE_TIMER_ALARM" });
    }
    wasAlarming = isAlarming;

    // [RESET-SIGNAL] 리셋 카운터가 바뀌면 재생 신호를 보냄
    const currentResetSeq = body.getAttribute("data-reset-seq");
    if (currentResetSeq !== null && currentResetSeq !== lastResetSeq) {
      lastResetSeq = currentResetSeq;
      chrome.runtime.sendMessage({ type: "MAPLE_TIMER_RESET" });
    }
  }

  const observer = new MutationObserver(checkAlarmState);
  observer.observe(document.body, {
    attributes: true,
    attributeFilter: ["class", "data-reset-seq"],
  });

  // 초기 상태 체크(새로고침 직후 이미 알람 상태일 수도 있으므로)
  checkAlarmState();
})();
