// background.js

function pauseAllMediaInPage() {
  // 이 함수는 각 탭 안에서 실행됩니다.
  document.querySelectorAll("video, audio").forEach((m) => {
    if (!m.paused) {
      try {
        m.pause();
      } catch (e) {
        /* 무시 */
      }
    }
  });
}

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "MAPLE_TIMER_ALARM") return;

  chrome.storage.local.get(["enabled"], ({ enabled }) => {
    // 기본값은 켜짐(true)
    if (enabled === false) return;

    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        if (!tab.id) continue;
        if (sender.tab && tab.id === sender.tab.id) continue; // 타이머 탭 자신은 제외
        if (!/^https?:/.test(tab.url || "")) continue; // 확장 프로그램/설정 페이지 등은 제외

        chrome.scripting
          .executeScript({
            target: { tabId: tab.id },
            func: pauseAllMediaInPage,
          })
          .catch(() => {
            /* 권한이 없는 특수 페이지 등은 조용히 무시 */
          });
      }
    });
  });
});
